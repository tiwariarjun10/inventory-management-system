<?php
// config.php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');  // your DB password
define('DB_NAME', 'inventory_db');
?>
