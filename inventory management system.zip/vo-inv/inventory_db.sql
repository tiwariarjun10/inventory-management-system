-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2025 at 07:25 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`) VALUES
(1, 'Apple'),
(2, 'Samsung'),
(4, 'OnePlus'),
(5, 'Seagate'),
(6, 'WD'),
(7, 'HP'),
(8, 'Canon'),
(9, 'Epson'),
(10, 'Dell'),
(11, 'Acer'),
(12, 'Lenovo'),
(13, 'Sony'),
(14, 'JBL'),
(15, 'Bose'),
(16, 'LG'),
(17, 'Cooler Master'),
(18, 'Corsair');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Mobile Phones'),
(2, 'Hard Drives'),
(3, 'Printers'),
(4, 'Monitors'),
(5, 'Speakers'),
(6, 'Laptops'),
(7, 'Televisions'),
(8, 'Camera'),
(12, 'Ear phones'),
(13, 'smart watch');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `product_id`, `quantity`) VALUES
(1, 17, 56677);

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `user_id`, `action`, `created_at`) VALUES
(1, 4, 'Deleted user \'user2\' (id=10)', '2025-03-11 13:58:38');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `order_date` date NOT NULL,
  `vat` decimal(5,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(5,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(10) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `contact`, `order_date`, `vat`, `discount`, `total_amount`, `status`) VALUES
(1, 'chris brown', '9861607550', '2025-03-11', 13.00, 10.00, 1955.97, 'done'),
(2, 'arjun tiwari', '9861607555', '2025-03-11', 13.00, 10.00, 925.97, 'done'),
(3, 'ram thapa', '9861607098', '2025-03-13', 13.00, 5.00, 1080.00, 'pending'),
(4, 'prashant bista', '9861607666', '2025-04-18', 13.00, 10.00, 1183.46, 'done'),
(5, 'ram stha', '4544554', '2025-04-29', 13.00, 0.00, 1467.87, 'pending'),
(6, 'josh hazelwood', '9861607669', '2025-04-30', 13.00, 0.00, 1130.00, 'done'),
(7, 'dinesh sharma', '9861607999', '2025-04-30', 13.00, 0.00, 565.00, 'done'),
(8, 'jitesh sharma', '9861607010', '2025-04-30', 13.00, 10.00, 1030.00, 'done'),
(9, 'ramesh saud', '9840839868', '2025-04-30', 13.00, 5.00, 1080.00, 'done'),
(10, 'arjun tiwari', '98616075', '2025-04-30', 13.00, 0.00, 338.99, 'done'),
(11, 'ram thapa', '9861607', '2025-04-30', 13.00, 0.00, 338.99, 'pending'),
(12, 'arjun tiwari', '9861607555', '2025-05-02', 13.00, 0.00, 1130.00, 'done'),
(13, 'hari acharya', '9861607533', '2025-05-05', 13.00, 5.00, 1080.00, 'done');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `line_total` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `line_total`) VALUES
(1, 1, 17, 1, 1000.00),
(2, 1, 37, 1, 899.00),
(3, 2, 37, 1, 899.00),
(4, 3, 89, 2, 1000.00),
(5, 4, 85, 1, 249.99),
(6, 4, 37, 1, 899.00),
(7, 5, 80, 1, 1299.00),
(8, 6, 17, 1, 1000.00),
(9, 7, 89, 1, 500.00),
(10, 8, 17, 1, 1000.00),
(11, 9, 17, 1, 1000.00),
(12, 10, 74, 1, 299.99),
(13, 11, 74, 1, 299.99),
(14, 12, 17, 1, 1000.00),
(15, 13, 17, 1, 1000.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category_id`, `brand_id`, `price`, `quantity`) VALUES
(17, 'jbl', 5, 14, 1000.00, 48),
(37, 'Apple iPhone 14', 1, 1, 999.00, 15),
(65, 'Samsung Galaxy S23', 1, 2, 799.00, 15),
(66, 'OnePlus 11', 1, 4, 729.00, 10),
(67, 'Seagate 1TB External HDD', 2, 5, 59.99, 20),
(68, 'WD Blue 500GB', 2, 6, 49.99, 25),
(69, 'HP LaserJet 1020', 3, 7, 129.99, 10),
(70, 'Canon Pixma G3000', 3, 8, 159.99, 8),
(71, 'Epson EcoTank L3150', 3, 9, 189.99, 5),
(72, 'Dell 24\" Monitor', 4, 10, 149.99, 10),
(73, 'Lenovo 27\" Monitor', 4, 12, 199.99, 7),
(74, 'Acer Nitro 27\" Gaming Monitor', 4, 11, 299.99, 5),
(75, 'JBL Flip 5', 5, 14, 79.99, 15),
(76, 'Bose SoundLink Mini', 5, 15, 129.99, 12),
(77, 'Apple MacBook Air M2', 6, 1, 1099.00, 8),
(78, 'Dell XPS 13', 6, 10, 999.00, 5),
(79, 'Lenovo ThinkPad X1 Carbon', 6, 12, 1199.00, 6),
(80, 'HP Spectre x360', 6, 7, 1299.00, 3),
(81, 'LG 55\" 4K OLED TV', 7, 16, 1399.99, 3),
(82, 'Sony Bravia 50\" Smart TV', 7, 13, 1199.99, 5),
(83, 'Canon EOS R6', 8, 8, 2499.00, 6),
(84, 'Sony Alpha A7 III', 8, 13, 1999.00, 4),
(85, 'Apple AirPods Pro', 12, 1, 249.99, 9),
(86, 'Sony WF-1000XM4', 12, 13, 279.99, 8),
(87, 'Bose QuietComfort Earbuds', 12, 15, 299.99, 7),
(88, 'onePlus 7t', 1, 4, 570.00, 20),
(89, 'onePlus node', 1, 4, 500.00, 16),
(90, 'Apple iPhone 16 pro max', 1, 1, 999.00, 15);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `vat` decimal(5,2) DEFAULT 0.00,
  `discount` decimal(5,2) DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`id`, `supplier_id`, `order_date`, `vat`, `discount`, `total_amount`) VALUES
(1, 20, '2025-04-17', 13.00, 10.00, 925.97),
(2, 18, '2025-04-17', 13.00, 20.00, 2508.21),
(3, 14, '2025-04-18', 13.00, 0.00, 11300.00);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_items`
--

CREATE TABLE `purchase_order_items` (
  `id` int(11) NOT NULL,
  `purchase_order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `line_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_order_items`
--

INSERT INTO `purchase_order_items` (`id`, `purchase_order_id`, `product_id`, `quantity`, `line_total`) VALUES
(1, 1, 37, 1, 899.00),
(2, 2, 37, 3, 2697.00),
(3, 3, 17, 10, 10000.00);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `sale_date` date DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `contact_person`, `phone`, `email`, `address`, `created_at`) VALUES
(11, 'TechZone Distributors', 'Rajesh Shrestha', '9812345678', 'techzone@nepal.com', 'Kathmandu, Nepal', '2025-03-13 11:21:27'),
(12, 'GadgetHub Nepal', 'Amit Thapa', '9856789012', 'gadgethub@gmail.com', 'Pokhara, Nepal', '2025-03-13 11:21:27'),
(13, 'SmartTech Suppliers', 'Bikash Karki', '9801122334', 'smarttech@gmail.com', 'Lalitpur, Nepal', '2025-03-13 11:21:27'),
(14, 'NextGen Electronics', 'Suraj Maharjan', '9822334455', 'nextgenelectronics@outlook.com', 'Bhaktapur, Nepal', '2025-03-13 11:21:27'),
(15, 'FutureGadgets Pvt. Ltd.', 'Prakash Lama', '9805566778', 'futuregadgets@gmail.com', 'Kathmandu, Nepal', '2025-03-13 11:21:27'),
(16, 'Infinity Tech Solutions', 'Rita Khatri', '9844455667', 'infinitytech@yahoo.com', 'Patan, Nepal', '2025-03-13 11:21:27'),
(17, 'Ultimate Gadgets', 'Dinesh Tamang', '9812233445', 'ultimategadgets@gmail.com', 'Hetauda, Nepal', '2025-03-13 11:21:27'),
(18, 'BestBuy Nepal', 'Sunil Gurung', '9867890123', 'bestbuynepal@furniture.com', 'Butwal, Nepal', '2025-03-13 11:21:27'),
(19, 'Gadget Empire', 'Sarita KC', '9819988776', 'gadgetempire@gmail.com', 'Dharan, Nepal', '2025-03-13 11:21:27'),
(20, 'ElectroMart Nepal', 'Hari Sharma', '9807766554', 'electromartnepal@nepal.com', 'Chitwan, Nepal', '2025-03-13 11:21:27'),
(21, 'ElectroMart ktm', 'shiva hari', '9819988776', 'electroktm@gmail.com', 'sankhu , kathmandu', '2025-05-02 08:00:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','employee') NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `name`, `email`, `status`) VALUES
(4, 'admin', '$2y$10$1E8GPsncAF9rBzJaK2QXa.R7i8ElzivbGxRJ6zTUMdhUEjvCKk5Pu', 'admin', 'arjun tiwari', 'arjuntiwari@gmail.com', 'active'),
(5, 'employee', '$2y$10$1XA/nOqWL.3MuoGDof88Y.z6MTS8RTJQ45qJvJTy0sR3zdKrgb4c6', 'employee', 'Employee User', 'employee@example.com', 'inactive'),
(6, 'user1', '$2y$10$MNy8hEYb9Ey5h/xzPXosheNFiziT.NuS5HJdD4O3rMgyKdVy41lr2', 'employee', NULL, 'user1@gmail.com', 'active'),
(7, 'admin1', '$2y$10$olhfNq18xCCgfrUoybBCNeqExXSvAeLqtrhGLiITEyMFu9AGKonZS', 'admin', NULL, 'admin@gmail.com', 'active'),
(8, 'user2', '$2y$10$3egjeDAA3KlwMnaxjOhRreCMLjWWuKgUo.HY9xrKOgYhn4DRHLDaq', 'employee', NULL, 'user2@gmail.com', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `purchase_order_items`
--
ALTER TABLE `purchase_order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchase_order_id` (`purchase_order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `purchase_order_items`
--
ALTER TABLE `purchase_order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`);

--
-- Constraints for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD CONSTRAINT `purchase_orders_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`);

--
-- Constraints for table `purchase_order_items`
--
ALTER TABLE `purchase_order_items`
  ADD CONSTRAINT `purchase_order_items_ibfk_1` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`),
  ADD CONSTRAINT `purchase_order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
