<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}
require_once '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = (int)$_POST['user_id'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate inputs
    $errors = [];
    
    if (empty($new_password)) {
        $errors[] = "Password is required.";
    } elseif (strlen($new_password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
    }
    
    if ($new_password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }
    
    // Check if user exists
    $check_user = $conn->prepare("SELECT username FROM users WHERE id = ?");
    $check_user->bind_param("i", $user_id);
    $check_user->execute();
    $result = $check_user->get_result();
    
    if ($result->num_rows === 0) {
        $errors[] = "User not found.";
    }
    
    // If no errors, update the password
    if (empty($errors)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        
        $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $update_stmt->bind_param("si", $hashed_password, $user_id);
        
        if ($update_stmt->execute()) {
            $_SESSION['message'] = "Password has been reset successfully.";
        } else {
            $_SESSION['error'] = "Failed to reset password. Please try again.";
        }
        
        $update_stmt->close();
    } else {
        $_SESSION['error'] = implode("<br>", $errors);
    }
    
    header("Location: users.php");
    exit();
}

// If not a POST request, redirect to users page
header("Location: users.php");
exit();
?>
