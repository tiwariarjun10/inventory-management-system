<?php
require_once '../db.php';

$product_id = (int)$_GET['product_id'];
$res = $conn->query("SELECT price FROM products WHERE id=$product_id");

if ($res && $res->num_rows > 0) {
    $row = $res->fetch_assoc();
    echo $row['price'];
} else {
    echo 0;
}
?>
