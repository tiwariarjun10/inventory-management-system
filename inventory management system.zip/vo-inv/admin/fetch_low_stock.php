<?php
session_start();
// Comment out the authentication check for testing if needed
if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

require_once '../db.php'; // Make sure the path is correct

// Fetch products with low stock (10 or fewer items)
$query = "SELECT id AS product_id, name AS product_name, quantity 
          FROM products
          WHERE quantity <= 10
          ORDER BY quantity ASC";

$result = $conn->query($query);

if ($result) {
    $lowStockItems = [];
    while ($row = $result->fetch_assoc()) {
        $lowStockItems[] = $row;
    }
    
    header('Content-Type: application/json');
    echo json_encode($lowStockItems);
} else {
    header('Content-Type: application/json');
    echo json_encode([
        'error' => 'Database error',
        'message' => $conn->error
    ]);
}

$conn->close();
?>
