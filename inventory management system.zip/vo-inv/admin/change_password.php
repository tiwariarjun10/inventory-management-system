<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit();
}
require_once '../db.php';
$user_id = $_SESSION['user_id'];
$message = '';

if(isset($_POST['change_password'])){
  $current_password = $_POST['current_password'];
  $new_password     = $_POST['new_password'];
  $confirm_password = $_POST['confirm_password'];
  
  // Verify current password
  $result = $conn->query("SELECT * FROM users WHERE id=$user_id");
  $user   = $result->fetch_assoc();
  
  if(password_verify($current_password, $user['password'])){
    if($new_password == $confirm_password){
      $hashed = password_hash($new_password, PASSWORD_DEFAULT);
      $conn->query("UPDATE users SET password='$hashed' WHERE id=$user_id");
      $message = "Password updated successfully.";
    } else {
      $message = "New passwords do not match.";
    }
  } else {
    $message = "Current password is incorrect.";
  }
}

?>
<?php include_once("navbar-sidebar.php"); ?>
<html>
<head>
<link rel="stylesheet" href="../assets/style.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <title>Change Password</title>
</head>

<body>

  <div class="container mt-4">
    <h1>Change Password</h1>
    <?php if($message != ''): ?>
      <div class="alert alert-info"><?php echo $message; ?></div>
    <?php endif; ?>
    <form method="post">
      <div class="form-group">
        <label>Current Password</label>
        <input type="password" name="current_password" class="form-control" required>
      </div>
      <div class="form-group">
        <label>New Password</label>
        <input type="password" name="new_password" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Confirm New Password</label>
        <input type="password" name="confirm_password" class="form-control" required>
      </div>
      <button type="submit" name="change_password" class="btn btn-primary">Change Password</button>
    </form>
  </div>
</body>
</html>
