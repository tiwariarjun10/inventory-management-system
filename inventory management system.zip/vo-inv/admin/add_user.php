<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}
require_once '../db.php';

// If form is submitted
if (isset($_POST['add_user'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $email    = $conn->real_escape_string($_POST['email']);
    $role     = $conn->real_escape_string($_POST['role']);
    $plainPass = $_POST['password'];
    $password = password_hash($plainPass, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, email, password, role) 
            VALUES ('$username', '$email', '$password', '$role')";
    $conn->query($sql);

    // If you have logs
    // logAction($conn, $_SESSION['user_id'], "Added user '$username' (role=$role)");

    $_SESSION['message'] = "User added successfully!";
    header("Location: users.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User | Digital Stock</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--mid-gray);
        }

        .page-title {
            font-weight: 600;
            color: var(--primary);
            font-size: 1.5rem;
            margin: 0;
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            border: none;
            margin-bottom: 1.5rem;
        }

        .card-header {
            background: linear-gradient(to right, var(--primary-light), var(--secondary));
            color: white;
            border-radius: 12px 12px 0 0 !important;
            padding: 1rem 1.25rem;
            font-weight: 600;
        }

        .card-body {
            padding: 1.5rem;
        }

        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid var(--mid-gray);
            padding: 0.6rem 1rem;
            font-size: 0.95rem;
            box-shadow: var(--shadow-sm);
            transition: all var(--transition-fast);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(87, 197, 182, 0.25);
        }

        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.25rem;
            font-weight: 500;
            transition: all var(--transition-fast);
        }

        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-secondary {
            background-color: var(--text-muted);
            border-color: var(--text-muted);
        }

        .btn-secondary:hover {
            background-color: var(--text-dark);
            border-color: var(--text-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .form-label {
            font-weight: 500;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .form-text {
            color: var(--text-muted);
            font-size: 0.85rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .password-strength {
            height: 5px;
            border-radius: 3px;
            margin-top: 0.5rem;
            background-color: var(--mid-gray);
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            width: 0;
            transition: width 0.3s ease;
        }

        .password-weak {
            width: 33%;
            background-color: var(--danger);
        }

        .password-medium {
            width: 66%;
            background-color: var(--warning);
        }

        .password-strong {
            width: 100%;
            background-color: var(--success);
        }
    </style>
</head>
<body>
<?php include_once("navbar-sidebar.php"); ?>

<div class="content-wrapper">
    <div class="page-header">
        <h1 class="page-title">Add New User</h1>
    </div>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-user-plus me-2"></i> User Information
        </div>
        <div class="card-body">
            <form method="post">
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" id="username" name="username" class="form-control" required>
                    </div>
                    <div class="form-text">Username must be unique and cannot be changed later.</div>
                </div>
                
                <div class="form-group">
                    <label for="email" class="form-label">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" id="password" name="password" class="form-control" required>
                        <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="password-strength mt-2">
                        <div class="password-strength-bar" id="passwordStrength"></div>
                    </div>
                    <div class="form-text">Password should be at least 8 characters with letters, numbers, and special characters.</div>
                </div>
                
                <div class="form-group">
                    <label for="role" class="form-label">User Role</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user-shield"></i></span>
                        <select id="role" name="role" class="form-select" required>
                            <option value="admin">Administrator</option>
                            <option value="employee">Employee</option>
                        </select>
                    </div>
                    <div class="form-text">
                        <strong>Administrator:</strong> Full access to all features.<br>
                        <strong>Employee:</strong> Limited access to inventory and sales.
                    </div>
                </div>
                
                <div class="d-flex gap-2">
                    <button type="submit" name="add_user" class="btn btn-primary">
                        <i class="fas fa-user-plus me-2"></i> Add User
                    </button>
                    <a href="users.php" class="btn btn-secondary">
                        <i class="fas fa-times me-2"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Toggle password visibility
    document.getElementById('togglePassword').addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const icon = this.querySelector('i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    });
    
    // Password strength indicator
    document.getElementById('password').addEventListener('input', function() {
        const password = this.value;
        const strengthBar = document.getElementById('passwordStrength');
        
        // Simple password strength check
        if (password.length === 0) {
            strengthBar.className = 'password-strength-bar';
            strengthBar.style.width = '0';
        } else if (password.length < 6) {
            strengthBar.className = 'password-strength-bar password-weak';
        } else if (password.length < 10 || !/[0-9]/.test(password) || !/[a-zA-Z]/.test(password)) {
            strengthBar.className = 'password-strength-bar password-medium';
        } else {
            strengthBar.className = 'password-strength-bar password-strong';
        }
    });
</script>
</body>
</html>
