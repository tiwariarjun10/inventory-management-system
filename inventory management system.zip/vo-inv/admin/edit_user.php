<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}
require_once '../db.php';

// 1) Check if we have an ID
if (!isset($_GET['id'])) {
    $_SESSION['message'] = "No user ID provided.";
    header("Location: users.php");
    exit();
}

$userId = (int)$_GET['id'];

// 2) Fetch user data
$res = $conn->query("SELECT * FROM users WHERE id=$userId");
if ($res->num_rows < 1) {
    $_SESSION['message'] = "User not found!";
    header("Location: users.php");
    exit();
}
$userData = $res->fetch_assoc();

// 3) If form is submitted
if (isset($_POST['update_user'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $email    = $conn->real_escape_string($_POST['email']);
    $role     = $conn->real_escape_string($_POST['role']);

    $conn->query("UPDATE users SET username='$username', email='$email', role='$role' WHERE id=$userId");

    // If you have logs
    // logAction($conn, $_SESSION['user_id'], "Updated user '$username' (id=$userId, role=$role)");

    $_SESSION['message'] = "User updated successfully!";
    header("Location: users.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit User (ID: <?php echo $userData['id']; ?>)</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <h2>Edit User (ID: <?php echo $userData['id']; ?>)</h2>

    <form method="post">
        <div class="form-group mb-3">
            <label>Username</label>
            <input type="text" name="username" class="form-control"
                   value="<?php echo htmlspecialchars($userData['username']); ?>" required>
        </div>
        <div class="form-group mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control"
                   value="<?php echo htmlspecialchars($userData['email']); ?>" required>
        </div>
        <div class="form-group mb-3">
            <label>Role</label>
            <select name="role" class="form-control">
                <option value="admin" <?php if($userData['role'] == 'admin') echo 'selected'; ?>>Admin</option>
                <option value="employee" <?php if($userData['role'] == 'employee') echo 'selected'; ?>>Employee</option>
            </select>
        </div>
        <!-- If you want to allow admin to reset password here, add an optional password field -->

        <button type="submit" name="update_user" class="btn btn-warning">Update</button>
        <a href="users.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>
