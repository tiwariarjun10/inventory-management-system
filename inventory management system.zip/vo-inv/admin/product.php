<?php
session_start();
require_once '../db.php'; // Adjust path if needed

// 1) Fetch categories (for dropdown)
$catResult = $conn->query("SELECT * FROM categories ORDER BY name ASC");

// 2) Fetch brands (for dropdown)
$brandResult = $conn->query("SELECT * FROM brands ORDER BY name ASC");

// (A) Add Product
if (isset($_POST['add_product'])) {
    $name        = $conn->real_escape_string($_POST['name']);
    $category_id = (int)$_POST['category_id'];
    $brand_id    = (int)$_POST['brand_id'];
    $price       = (float)$_POST['price'];
    $quantity    = (int)$_POST['quantity'];

    $sql = "
      INSERT INTO products (name, category_id, brand_id, price, quantity)
      VALUES ('$name', $category_id, $brand_id, $price, $quantity)
    ";
    $conn->query($sql);
    header("Location: product.php");
    exit();
}

// (B) If ?edit=ID is in the URL, fetch that product for editing
$editRow = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $query  = $conn->query("
      SELECT * FROM products
      WHERE id = $editId
    ");
    if ($query && $query->num_rows > 0) {
        $editRow = $query->fetch_assoc();
    }
}

// (C) Update Product
if (isset($_POST['update_product'])) {
    $id          = (int)$_POST['id'];
    $name        = $conn->real_escape_string($_POST['name']);
    $category_id = (int)$_POST['category_id'];
    $brand_id    = (int)$_POST['brand_id'];
    $price       = (float)$_POST['price'];
    $quantity    = (int)$_POST['quantity'];

    $sql = "
      UPDATE products
      SET name='$name',
          category_id=$category_id,
          brand_id=$brand_id,
          price=$price,
          quantity=$quantity
      WHERE id=$id
    ";
    $conn->query($sql);
    header("Location: product.php");
    exit();
}

// (D) Delete Product
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    $conn->query("DELETE FROM products WHERE id=$deleteId");
    header("Location: product.php");
    exit();
}

// (E) Fetch All Products (joined with categories and brands)
$sql = "
  SELECT p.id,
         p.name AS product_name,
         p.price,
         p.quantity,
         c.name AS category_name,
         b.name AS brand_name
  FROM products p
  LEFT JOIN categories c ON p.category_id = c.id
  LEFT JOIN brands b ON p.brand_id = b.id
  ORDER BY p.id ASC
";
$products = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products | Digital Stock</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--mid-gray);
        }

        .page-title {
            font-weight: 600;
            color: var(--primary);
            font-size: 1.5rem;
            margin: 0;
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            border: none;
            margin-bottom: 1.5rem;
        }

        .card-header {
            background: linear-gradient(to right, var(--primary-light), var(--secondary));
            color: white;
            border-radius: 12px 12px 0 0 !important;
            padding: 1rem 1.25rem;
            font-weight: 600;
        }

        .card-body {
            padding: 1.5rem;
        }

        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid var(--mid-gray);
            padding: 0.6rem 1rem;
            font-size: 0.95rem;
            box-shadow: var(--shadow-sm);
            transition: all var(--transition-fast);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(87, 197, 182, 0.25);
        }

        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.25rem;
            font-weight: 500;
            transition: all var(--transition-fast);
        }

        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-success {
            background-color: var(--success);
            border-color: var(--success);
        }

        .btn-success:hover {
            background-color: #0da56f;
            border-color: #0da56f;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-warning {
            background-color: var(--warning);
            border-color: var(--warning);
            color: white;
        }

        .btn-warning:hover {
            background-color: #e08e0b;
            border-color: #e08e0b;
            color: white;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-danger {
            background-color: var(--danger);
            border-color: var(--danger);
        }

        .btn-danger:hover {
            background-color: #dc2626;
            border-color: #dc2626;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: var(--primary);
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: none;
            padding: 0.75rem 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-color: var(--mid-gray);
            font-size: 0.95rem;
        }

        .table tbody tr:hover {
            background-color: rgba(87, 197, 182, 0.05);
        }

        .edit-form {
            background-color: rgba(87, 197, 182, 0.1);
            border-left: 4px solid var(--accent);
            padding: 1.25rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }

        .btn-sm {
            padding: 0.4rem 0.75rem;
            font-size: 0.85rem;
        }

        .stock-badge {
            padding: 0.35rem 0.75rem;
            border-radius: 50rem;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
        }

        .stock-low {
            background-color: rgba(245, 158, 11, 0.15);
            color: var(--warning);
        }

        .stock-ok {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }
    </style>
</head>
<body>
<?php include_once("navbar-sidebar.php"); ?>

<div class="content-wrapper">
    <div class="page-header">
        <h1 class="page-title">Manage Products</h1>
    </div>

    <div class="search-container mb-4">
        <div class="row">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                    <input type="text" id="productSearch" class="form-control" placeholder="Search products by name, category, brand...">
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-plus-circle me-2"></i> Add New Product
        </div>
        <div class="card-body">
            <form method="post" class="row g-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Product Name</label>
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <label for="category_id" class="form-label">Category</label>
                    <select id="category_id" name="category_id" class="form-select" required>
                        <option value="">Select Category</option>
                        <?php while($cat = $catResult->fetch_assoc()): ?>
                            <option value="<?php echo $cat['id']; ?>">
                                <?php echo $cat['name']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="brand_id" class="form-label">Brand</label>
                    <select id="brand_id" name="brand_id" class="form-select">
                        <option value="">Select Brand</option>
                        <?php
                        // Reset the brand result pointer
                        $brandResult->data_seek(0);
                        while($br = $brandResult->fetch_assoc()):
                        ?>
                            <option value="<?php echo $br['id']; ?>">
                                <?php echo $br['name']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="price" class="form-label">Price</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" step="0.01" id="price" name="price" class="form-control" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="quantity" class="form-label">Quantity</label>
                    <input type="number" id="quantity" name="quantity" class="form-control" required>
                </div>
                <div class="col-12">
                    <button type="submit" name="add_product" class="btn btn-success">
                        <i class="fas fa-plus-circle me-2"></i> Add Product
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Product Form (only shown if ?edit=ID) -->
    <?php if ($editRow): ?>
    <div class="edit-form">
        <h5 class="mb-3">Edit Product (ID: <?php echo $editRow['id']; ?>)</h5>
        <form method="post" class="row g-3">
            <input type="hidden" name="id" value="<?php echo $editRow['id']; ?>">
            <div class="col-md-6">
                <label for="edit_name" class="form-label">Product Name</label>
                <input type="text" id="edit_name" name="name" class="form-control" value="<?php echo $editRow['name']; ?>" required>
            </div>
            <div class="col-md-3">
                <label for="edit_category_id" class="form-label">Category</label>
                <select id="edit_category_id" name="category_id" class="form-select" required>
                    <?php
                    // Re-fetch categories
                    $catAgain = $conn->query("SELECT * FROM categories ORDER BY name ASC");
                    while($c = $catAgain->fetch_assoc()):
                        $selected = ($c['id'] == $editRow['category_id']) ? 'selected' : '';
                    ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo $selected; ?>>
                            <?php echo $c['name']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="edit_brand_id" class="form-label">Brand</label>
                <select id="edit_brand_id" name="brand_id" class="form-select">
                    <option value="">Select Brand</option>
                    <?php
                    $brandAgain = $conn->query("SELECT * FROM brands ORDER BY name ASC");
                    while($b = $brandAgain->fetch_assoc()):
                        $selected = ($b['id'] == $editRow['brand_id']) ? 'selected' : '';
                    ?>
                        <option value="<?php echo $b['id']; ?>" <?php echo $selected; ?>>
                            <?php echo $b['name']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label for="edit_price" class="form-label">Price</label>
                <div class="input-group">
                    <span class="input-group-text">$</span>
                    <input type="number" step="0.01" id="edit_price" name="price" class="form-control" value="<?php echo $editRow['price']; ?>" required>
                </div>
            </div>
            <div class="col-md-6">
                <label for="edit_quantity" class="form-label">Quantity</label>
                <input type="number" id="edit_quantity" name="quantity" class="form-control" value="<?php echo $editRow['quantity']; ?>" required>
            </div>
            <div class="col-12">
                <button type="submit" name="update_product" class="btn btn-warning">
                    <i class="fas fa-save me-2"></i> Update Product
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-box-open me-2"></i> Product List
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Brand</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th style="width: 200px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($row = $products->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['product_name']; ?></td>
                            <td><?php echo $row['category_name'] ?: '-'; ?></td>
                            <td><?php echo $row['brand_name'] ?: '-'; ?></td>
                            <td>$<?php echo number_format($row['price'], 2); ?></td>
                            <td>
                                <?php 
                                $quantity = (int)$row['quantity'];
                                $stockClass = $quantity <= 10 ? 'stock-low' : 'stock-ok';
                                $stockIcon = $quantity <= 10 ? 'fa-exclamation-triangle' : 'fa-check-circle';
                                ?>
                                <span class="stock-badge <?php echo $stockClass; ?>">
                                    <i class="fas <?php echo $stockIcon; ?> me-1"></i>
                                    <?php echo $quantity; ?>
                                </span>
                            </td>
                            <td>
                                <a href="product.php?edit=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-edit me-1"></i> Edit
                                </a>
                                <a href="product.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this product?');">
                                    <i class="fas fa-trash-alt me-1"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('productSearch').addEventListener('keyup', function() {
        const searchValue = this.value.toLowerCase();
        const table = document.querySelector('.table');
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            let found = false;
            const cells = row.querySelectorAll('td');
            
            cells.forEach(cell => {
                if (cell.textContent.toLowerCase().includes(searchValue)) {
                    found = true;
                }
            });
            
            row.style.display = found ? '' : 'none';
        });
    });
</script>
</body>
</html>
