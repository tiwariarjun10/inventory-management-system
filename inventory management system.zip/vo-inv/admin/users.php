<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}
require_once '../db.php';

// Optional: If you have logs
function logAction($conn, $userId, $action) {
    // If no logs table, remove or comment out
    $stmt = $conn->prepare("INSERT INTO logs (user_id, action) VALUES (?, ?)");
    $stmt->bind_param("is", $userId, $action);
    $stmt->execute();
    $stmt->close();
}

// Handle DELETE
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];

    // Avoid deleting yourself
    if ($deleteId != $_SESSION['user_id']) {
        // For logs
        $delUserRes = $conn->query("SELECT username FROM users WHERE id=$deleteId");
        $delRow     = $delUserRes->fetch_assoc();

        $conn->query("DELETE FROM users WHERE id=$deleteId");

        // Log
        if (function_exists('logAction') && $delRow) {
            logAction($conn, $_SESSION['user_id'], "Deleted user '{$delRow['username']}' (id=$deleteId)");
        }

        $_SESSION['message'] = "User deleted successfully!";
    }
    header("Location: users.php");
    exit();
}

// Fetch all users
$users = $conn->query("SELECT * FROM users ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management | Digital Stock</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            --info: #3b82f6;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--mid-gray);
        }

        .page-title {
            font-weight: 600;
            color: var(--primary);
            font-size: 1.5rem;
            margin: 0;
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            border: none;
            margin-bottom: 1.5rem;
        }

        .card-header {
            background: linear-gradient(to right, var(--primary-light), var(--secondary));
            color: white;
            border-radius: 12px 12px 0 0 !important;
            padding: 1rem 1.25rem;
            font-weight: 600;
        }

        .card-body {
            padding: 1.5rem;
        }

        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.25rem;
            font-weight: 500;
            transition: all var(--transition-fast);
        }

        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-info {
            background-color: var(--info);
            border-color: var(--info);
            color: white;
        }

        .btn-info:hover {
            background-color: #2563eb;
            border-color: #2563eb;
            color: white;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-warning {
            background-color: var(--warning);
            border-color: var(--warning);
            color: white;
        }

        .btn-warning:hover {
            background-color: #e08e0b;
            border-color: #e08e0b;
            color: white;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-danger {
            background-color: var(--danger);
            border-color: var(--danger);
        }

        .btn-danger:hover {
            background-color: #dc2626;
            border-color: #dc2626;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-sm {
            padding: 0.4rem 0.75rem;
            font-size: 0.85rem;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: var(--primary);
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: none;
            padding: 0.75rem 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-color: var(--mid-gray);
            font-size: 0.95rem;
        }

        .table tbody tr:hover {
            background-color: rgba(87, 197, 182, 0.05);
        }

        .alert {
            border-radius: 8px;
            box-shadow: var(--shadow-sm);
            border: none;
        }

        .alert-success {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        .role-badge {
            padding: 0.35rem 0.75rem;
            border-radius: 50rem;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
        }

        .role-admin {
            background-color: rgba(59, 130, 246, 0.15);
            color: var(--info);
        }

        .role-employee {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        .role-other {
            background-color: rgba(245, 158, 11, 0.15);
            color: var(--warning);
        }
    </style>
</head>
<body>
<?php include_once("navbar-sidebar.php"); ?>

<div class="content-wrapper">
    <div class="page-header">
        <h1 class="page-title">User Management</h1>
        <div>
            <a href="logs.php" class="btn btn-info me-2">
                <i class="fas fa-history me-2"></i> View Logs
            </a>
            <a href="add_user.php" class="btn btn-primary">
                <i class="fas fa-user-plus me-2"></i> Add New User
            </a>
        </div>
    </div>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle me-2"></i>
            <?php
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle me-2"></i>
            <?php
                echo $_SESSION['error'];
                unset($_SESSION['error']);
            ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-users me-2"></i> System Users
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th style="width: 200px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while($row = $users->fetch_assoc()): 
                        $roleClass = '';
                        if ($row['role'] === 'admin') {
                            $roleClass = 'role-admin';
                        } elseif ($row['role'] === 'employee') {
                            $roleClass = 'role-employee';
                        } else {
                            $roleClass = 'role-other';
                        }
                    ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td>
                                <span class="role-badge <?php echo $roleClass; ?>">
                                    <i class="fas fa-user-shield me-1"></i>
                                    <?php echo strtoupper(htmlspecialchars($row['role'])); ?>
                                </span>
                            </td>
                            <td>
                                <a href="edit_user.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">
                                    <i class="fas fa-edit me-1"></i> Edit
                                </a>
                                <button type="button" class="btn btn-info btn-sm" 
                                        onclick="openResetPasswordModal(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars($row['username']); ?>')">
                                    <i class="fas fa-key me-1"></i> Reset Password
                                </button>
                                <?php if ($row['id'] != $_SESSION['user_id']): ?>
                                    <a href="users.php?delete=<?php echo $row['id']; ?>" 
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Are you sure you want to delete this user?');">
                                        <i class="fas fa-trash-alt me-1"></i> Delete
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<!-- Reset Password Modal -->
<div class="modal fade" id="resetPasswordModal" tabindex="-1" aria-labelledby="resetPasswordModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="resetPasswordModalLabel">Reset Password</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="resetPasswordForm" method="post" action="reset_password.php">
                <div class="modal-body">
                    <input type="hidden" id="reset_user_id" name="user_id">
                    <p>You are resetting the password for: <strong id="reset_username"></strong></p>
                    
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="form-text">Password should be at least 8 characters with letters, numbers, and special characters.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        <div id="password_match_error" class="text-danger" style="display: none;">
                            Passwords do not match.
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Reset Password</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>

<script>
    // Function to open the reset password modal
    function openResetPasswordModal(userId, username) {
        document.getElementById('reset_user_id').value = userId;
        document.getElementById('reset_username').textContent = username;
        
        // Clear previous values
        document.getElementById('new_password').value = '';
        document.getElementById('confirm_password').value = '';
        document.getElementById('password_match_error').style.display = 'none';
        
        // Open the modal
        var resetPasswordModal = new bootstrap.Modal(document.getElementById('resetPasswordModal'));
        resetPasswordModal.show();
    }
    
    // Toggle password visibility
    document.getElementById('togglePassword').addEventListener('click', function() {
        const passwordInput = document.getElementById('new_password');
        const icon = this.querySelector('i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    });
    
    // Check if passwords match
    document.getElementById('confirm_password').addEventListener('input', function() {
        const newPassword = document.getElementById('new_password').value;
        const confirmPassword = this.value;
        const errorElement = document.getElementById('password_match_error');
        
        if (newPassword !== confirmPassword) {
            errorElement.style.display = 'block';
        } else {
            errorElement.style.display = 'none';
        }
    });
    
    // Form validation before submit
    document.getElementById('resetPasswordForm').addEventListener('submit', function(event) {
        const newPassword = document.getElementById('new_password').value;
        const confirmPassword = document.getElementById('confirm_password').value;
        
        if (newPassword !== confirmPassword) {
            event.preventDefault();
            document.getElementById('password_match_error').style.display = 'block';
        }
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
