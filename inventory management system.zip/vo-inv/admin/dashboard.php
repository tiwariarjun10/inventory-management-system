<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}
require_once '../db.php'; // Adjust path if needed

// Fetching data
$catRes = $conn->query("SELECT COUNT(*) AS cnt FROM categories");
$totalCategories = $catRes->fetch_assoc()['cnt'] ?? 0;

$brandRes = $conn->query("SELECT COUNT(*) AS cnt FROM brands");
$totalBrands = $brandRes->fetch_assoc()['cnt'] ?? 0;

$prodRes = $conn->query("SELECT COUNT(*) AS cnt FROM products");
$totalProducts = $prodRes->fetch_assoc()['cnt'] ?? 0;

$userRes = $conn->query("SELECT COUNT(*) AS cnt FROM users");
$totalUsers = $userRes->fetch_assoc()['cnt'] ?? 0;

$custRes = $conn->query("SELECT COUNT(DISTINCT customer_name) AS cnt FROM orders");
$totalCustomers = $custRes->fetch_assoc()['cnt'] ?? 0;

$suppRes = $conn->query("SELECT COUNT(*) AS cnt FROM suppliers");
$totalSuppliers = $suppRes->fetch_assoc()['cnt'] ?? 0;

$salesOrderRes = $conn->query("SELECT COUNT(*) AS cnt FROM orders");
$totalSalesOrders = $salesOrderRes->fetch_assoc()['cnt'] ?? 0;

$todaySalesQuery = $conn->query("
    SELECT IFNULL(SUM(total_amount),0) AS total 
    FROM orders 
    WHERE order_date = CURDATE()
      AND status = 'done'
");

$todaySales = $todaySalesQuery->fetch_assoc()['total'];


$purchaseOrderRes = $conn->query("SELECT COUNT(*) AS cnt FROM purchase_orders");
$totalPurchaseOrders = $purchaseOrderRes->fetch_assoc()['cnt'] ?? 0;

$lifetimeSalesRes = $conn->query("SELECT IFNULL(SUM(total_amount),0) AS total FROM orders WHERE status = 'done'");
$lifetimeSales = $lifetimeSalesRes->fetch_assoc()['total'] ?? 0;

$lifetimePurchaseRes = $conn->query("SELECT IFNULL(SUM(total_amount),0) AS total FROM purchase_orders");
$lifetimePurchase = $lifetimePurchaseRes->fetch_assoc()['total'] ?? 0;

$todayPurchaseRes = $conn->query("SELECT IFNULL(SUM(total_amount),0) AS total FROM purchase_orders WHERE order_date = CURDATE()");
$todayPurchase = $todayPurchaseRes->fetch_assoc()['total'] ?? 0;

$stockAlertRes = $conn->query("
    SELECT id AS product_id, name AS product_name, quantity 
    FROM products
    WHERE quantity <= 10
    ORDER BY quantity ASC
");

// Calculate profit (mock data for demo)
$profit = $lifetimeSales - $lifetimePurchase;
$profitMargin = ($lifetimeSales > 0) ? ($profit / $lifetimeSales) * 100 : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Digital Stock</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
            --transition-slow: 0.5s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
            line-height: 1.6;
        }

        /* Dashboard header */
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--mid-gray);
        }

        .dashboard-title {
            font-weight: 600;
            color: var(--primary);
            font-size: 1.5rem;
            margin: 0;
        }

        .dashboard-date {
            color: var(--text-muted);
            font-size: 0.9rem;
            background: white;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            box-shadow: var(--shadow-sm);
        }

        /* Card styles */
        .stat-card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            padding: 1.5rem;
            height: 100%;
            transition: all var(--transition-normal);
            border-top: 4px solid transparent;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            box-shadow: var(--shadow-lg);
            transform: translateY(-5px);
        }

        .stat-card .icon {
            position: absolute;
            top: 1rem;
            right: 1rem;
            font-size: 1.5rem;
            opacity: 0.8;
        }

        .stat-card .title {
            font-size: 0.875rem;
            color: var(--text-muted);
            margin-bottom: 0.5rem;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card .value {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--dark);
        }

        .stat-card .trend {
            font-size: 0.75rem;
            display: flex;
            align-items: center;
            margin-top: 0.5rem;
        }

        .trend-up {
            color: var(--success);
        }

        .trend-down {
            color: var(--danger);
        }

        /* Card color variations */
        .card-primary {
            border-top-color: var(--primary);
        }
        .card-primary .icon {
            color: var(--primary);
        }

        .card-secondary {
            border-top-color: var(--secondary);
        }
        .card-secondary .icon {
            color: var(--secondary);
        }

        .card-accent {
            border-top-color: var(--accent);
        }
        .card-accent .icon {
            color: var(--accent);
        }

        .card-success {
            border-top-color: var(--success);
        }
        .card-success .icon {
            color: var(--success);
        }

        .card-warning {
            border-top-color: var(--warning);
        }
        .card-warning .icon {
            color: var(--warning);
        }

        .card-danger {
            border-top-color: var(--danger);
        }
        .card-danger .icon {
            color: var(--danger);
        }

        /* Section styles */
        .card-section {
            margin-bottom: 2rem;
        }

        .section-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--primary);
            display: flex;
            align-items: center;
            padding-left: 0.5rem;
            border-left: 4px solid var(--accent);
        }

        .section-title i {
            margin-right: 0.5rem;
            color: var(--accent);
        }

        /* Summary card */
        .summary-card {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-md);
        }

        .summary-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1rem;
            opacity: 0.9;
        }

        .summary-value {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .summary-subtitle {
            font-size: 0.875rem;
            opacity: 0.8;
        }

        /* Quick actions */
        .quick-actions {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .quick-action-btn {
            background-color: white;
            border: none;
            border-radius: 8px;
            padding: 0.75rem 1rem;
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--primary);
            box-shadow: var(--shadow-sm);
            transition: all var(--transition-fast);
            display: flex;
            align-items: center;
        }

        .quick-action-btn i {
            margin-right: 0.5rem;
        }

        .quick-action-btn:hover {
            background-color: var(--primary);
            color: white;
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        /* Table styles */
        .table-container {
            background-color: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            padding: 1.25rem;
            margin-bottom: 1.5rem;
            overflow: hidden;
        }

        .table-container .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: var(--primary);
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: none;
            padding: 0.75rem 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-color: var(--mid-gray);
            font-size: 0.875rem;
        }

        .table tbody tr:hover {
            background-color: rgba(87, 197, 182, 0.05);
        }

        /* Status badges */
        .status-badge {
            padding: 0.35rem 0.75rem;
            border-radius: 50rem;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-badge i {
            margin-right: 0.25rem;
            font-size: 0.7rem;
        }

        .status-out {
            background-color: rgba(239, 68, 68, 0.15);
            color: var(--danger);
        }

        .status-low {
            background-color: rgba(245, 158, 11, 0.15);
            color: var(--warning);
        }

        .status-ok {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        /* Action buttons */
        .btn-action {
            padding: 0.375rem 0.75rem;
            font-size: 0.75rem;
            font-weight: 600;
            border-radius: 6px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all var(--transition-fast);
        }

        .btn-primary-custom {
            background-color: var(--primary);
            border-color: var(--primary);
            color: white;
        }

        .btn-primary-custom:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            color: white;
            transform: translateY(-1px);
        }

        /* Progress bars */
        .progress {
            height: 6px;
            margin-top: 0.75rem;
            background-color: var(--light-gray);
            border-radius: 3px;
        }

        .progress-bar-primary {
            background-color: var(--primary);
        }

        .progress-bar-success {
            background-color: var(--success);
        }

        .progress-bar-warning {
            background-color: var(--warning);
        }

        .progress-bar-danger {
            background-color: var(--danger);
        }

        /* Animation for cards */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fade-in-up {
            animation: fadeInUp 0.5s ease forwards;
            opacity: 0;
        }

        /* Responsive adjustments */
        @media (max-width: 992px) {
            .stat-card .value {
                font-size: 1.5rem;
            }
            
            .summary-value {
                font-size: 2rem;
            }
        }

        @media (max-width: 768px) {
            .dashboard-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .dashboard-date {
                margin-top: 0.5rem;
            }
            
            .quick-actions {
                flex-wrap: wrap;
            }
        }
    </style>
</head>
<body>

<?php include_once("navbar-sidebar.php"); ?>

<div class="content-wrapper">
    <div class="dashboard-header">
        <h1 class="dashboard-title">Dashboard Overview</h1>
        <div class="dashboard-date">
            <i class="fas fa-calendar-alt me-2"></i>
            <?php echo date("l, F d, Y"); ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <!-- <div class="quick-actions">
        <button class="quick-action-btn">
            <i class="fas fa-plus"></i> New Order
        </button>
        <button class="quick-action-btn">
            <i class="fas fa-box"></i> Add Product
        </button>
        <button class="quick-action-btn">
            <i class="fas fa-file-invoice"></i> Generate Report
        </button>
    </div> -->

    <!-- Summary Card -->
    <div class="summary-card">
        <div class="row">
            <div class="col-md-6">
                <div class="summary-title">Total Revenue</div>
                <div class="summary-value">$<?php echo number_format($lifetimeSales, 2); ?></div>
                <div class="summary-subtitle">Lifetime sales across all products</div>
            </div>
            <div class="col-md-6 text-md-end">
                <div class="summary-title">Profit Margin</div>
                <div class="summary-value"><?php echo number_format($profitMargin, 1); ?>%</div>
                <div class="summary-subtitle">Based on sales and purchase data</div>
            </div>
        </div>
    </div>

    <!-- Inventory Stats -->
    <div class="card-section">
        <h2 class="section-title"><i class="fas fa-box"></i> Inventory Statistics</h2>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="stat-card card-primary animate-fade-in-up" style="animation-delay: 0.1s">
                    <i class="icon fas fa-tags"></i>
                    <div class="title">Total Categories</div>
                    <div class="value"><?php echo $totalCategories; ?></div>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-primary" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card card-primary animate-fade-in-up" style="animation-delay: 0.2s">
                    <i class="icon fas fa-copyright"></i>
                    <div class="title">Total Brands</div>
                    <div class="value"><?php echo $totalBrands; ?></div>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-primary" role="progressbar" style="width: 65%" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card card-primary animate-fade-in-up" style="animation-delay: 0.3s">
                    <i class="icon fas fa-cubes"></i>
                    <div class="title">Total Products</div>
                    <div class="value"><?php echo $totalProducts; ?></div>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-primary" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- User Stats -->
    <div class="card-section">
        <h2 class="section-title"><i class="fas fa-users"></i> User Statistics</h2>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="stat-card card-secondary animate-fade-in-up" style="animation-delay: 0.4s">
                    <i class="icon fas fa-user-shield"></i>
                    <div class="title">Total Users</div>
                    <div class="value"><?php echo $totalUsers; ?></div>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-primary" role="progressbar" style="width: 70%" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card card-secondary animate-fade-in-up" style="animation-delay: 0.5s">
                    <i class="icon fas fa-user-tag"></i>
                    <div class="title">Total Customers</div>
                    <div class="value"><?php echo $totalCustomers; ?></div>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-primary" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card card-secondary animate-fade-in-up" style="animation-delay: 0.6s">
                    <i class="icon fas fa-truck"></i>
                    <div class="title">Total Suppliers</div>
                    <div class="value"><?php echo $totalSuppliers; ?></div>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-primary" role="progressbar" style="width: 60%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sales Stats -->
    <div class="card-section">
        <h2 class="section-title"><i class="fas fa-chart-line"></i> Sales Statistics</h2>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="stat-card card-success animate-fade-in-up" style="animation-delay: 0.7s">
                    <i class="icon fas fa-shopping-cart"></i>
                    <div class="title">Sales Orders</div>
                    <div class="value"><?php echo $totalSalesOrders; ?></div>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-success" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card card-success animate-fade-in-up" style="animation-delay: 0.8s">
                    <i class="icon fas fa-dollar-sign"></i>
                    <div class="title">Today's Sales</div>
                    <div class="value">$<?php echo number_format($todaySales, 2); ?></div>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-success" role="progressbar" style="width: 65%" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card card-success animate-fade-in-up" style="animation-delay: 0.9s">
                    <i class="icon fas fa-chart-bar"></i>
                    <div class="title">Lifetime Sales</div>
                    <div class="value">$<?php echo number_format($lifetimeSales, 2); ?></div>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-success" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Purchase Stats -->
    <div class="card-section">
        <h2 class="section-title"><i class="fas fa-shopping-basket"></i> Purchase Statistics</h2>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="stat-card card-warning animate-fade-in-up" style="animation-delay: 1.0s">
                    <i class="icon fas fa-file-invoice"></i>
                    <div class="title">Purchase Orders</div>
                    <div class="value"><?php echo $totalPurchaseOrders; ?></div>
                   
                    <div class="progress">
                        <div class="progress-bar progress-bar-warning" role="progressbar" style="width: 55%" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card card-warning animate-fade-in-up" style="animation-delay: 1.1s">
                    <i class="icon fas fa-money-bill-wave"></i>
                    <div class="title">Today's Purchase</div>
                    <div class="value">$<?php echo number_format($todayPurchase, 2); ?></div>
                   
                    <div class="progress">
                        <div class="progress-bar progress-bar-warning" role="progressbar" style="width: 45%" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card card-warning animate-fade-in-up" style="animation-delay: 1.2s">
                    <i class="icon fas fa-chart-pie"></i>
                    <div class="title">Lifetime Purchase</div>
                    <div class="value">$<?php echo number_format($lifetimePurchase, 2); ?></div>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-warning" role="progressbar" style="width: 70%" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Initialize animations when the page loads
    document.addEventListener('DOMContentLoaded', function() {
        // Add animation classes with delays
        const animatedElements = document.querySelectorAll('.animate-fade-in-up');
        animatedElements.forEach((element, index) => {
            element.style.animationDelay = `${0.1 * index}s`;
        });
    });
</script>
<script>
    // Fetch low stock items for notifications
    document.addEventListener('DOMContentLoaded', function() {
        // Fetch low stock items via AJAX
        fetch('fetch_low_stock.php')
            .then(response => response.json())
            .then(data => {
                const notificationList = document.getElementById('notification-list');
                const notificationCount = document.getElementById('notification-count');
                
                if (data.length > 0) {
                    // Update notification count
                    notificationCount.textContent = data.length;
                    
                    // Clear loading message
                    notificationList.innerHTML = '';
                    
                    // Add each low stock item to the notification list
                    data.forEach(item => {
                        const statusClass = item.quantity === 0 ? 'danger' : 'warning';
                        const statusText = item.quantity === 0 ? 'Out of Stock' : 'Low Stock';
                        const statusIcon = item.quantity === 0 ? 'fa-times-circle' : 'fa-exclamation-triangle';
                        
                        const notificationItem = document.createElement('div');
                        notificationItem.className = 'notification-item p-3 border-bottom';
                        notificationItem.innerHTML = `
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <i class="fas ${statusIcon} text-${statusClass} fa-lg"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="mb-1">${item.product_name}</h6>
                                    <p class="mb-0 text-${statusClass} small">
                                        <strong>${statusText}:</strong> ${item.quantity} units remaining
                                    </p>
                                </div>
                            </div>
                        `;
                        notificationList.appendChild(notificationItem);
                    });
                } else {
                    // No low stock items
                    notificationList.innerHTML = `
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-check-circle fa-2x mb-2"></i>
                            <p class="mb-0">No stock alerts at this time.</p>
                        </div>
                    `;
                    notificationCount.textContent = '0';
                }
            })
            .catch(error => {
                console.error('Error fetching low stock items:', error);
                document.getElementById('notification-list').innerHTML = `
                    <div class="text-center py-4 text-muted">
                        <i class="fas fa-exclamation-circle fa-2x mb-2"></i>
                        <p class="mb-0">Error loading notifications.</p>
                    </div>
                `;
            });
    });
</script>
</body>
</html>
