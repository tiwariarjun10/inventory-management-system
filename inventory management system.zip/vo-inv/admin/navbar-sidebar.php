<?php
// Example: we store user role in $_SESSION['role'] = 'admin' or 'employee' or others
$roleText = 'GUEST';
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'admin') {
        $roleText = 'ADMIN';
    } elseif ($_SESSION['role'] === 'employee') {
        $roleText = 'EMPLOYEE';
    } else {
        $roleText = strtoupper($_SESSION['role']);
    }
}

// Get current page for active menu highlighting
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Digital Stock Management</title>

  <!-- Bootstrap 5 CSS -->
  <link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
  />
  <!-- Font Awesome for Icons -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  />
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <style>
  :root {
    /* Main color palette */
    --primary: #1a5f7a;
    --primary-dark: #124b61;
    --primary-light: #2e7d9a;
    --secondary: #159895;
    --accent: #57c5b6;
    --accent-light: #7dd3c8;
    --dark: #1e293b;
    --light: #f8fafc;
    --light-gray: #f1f5f9;
    --mid-gray: #e2e8f0;
    --text-dark: #334155;
    --text-muted: #64748b;
    --text-light: #f8fafc;
    --danger: #ef4444;
    --warning: #f59e0b;
    --success: #10b981;
    
    /* Shadows */
    --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    
    /* Transitions */
    --transition-fast: 0.15s ease;
    --transition-normal: 0.3s ease;
    --transition-slow: 0.5s ease;
  }

  body {
    background-color: var(--light-gray);
    color: var(--text-dark);
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
    overflow-x: hidden;
  }

  /* NAVBAR */
  .navbar {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 999;
    height: 64px;
    box-shadow: var(--shadow-md);
    padding: 0 1.5rem;
  }

  .navbar-brand {
    font-weight: 700;
    color: var(--text-light);
    font-size: 1.25rem;
    display: flex;
    align-items: center;
    letter-spacing: 0.5px;
  }

  .navbar-brand i {
    margin-right: 0.75rem;
    font-size: 1.5rem;
    color: var(--accent-light);
    filter: drop-shadow(0 2px 2px rgba(0, 0, 0, 0.2));
  }

  .navbar .nav-item {
    display: flex;
    align-items: center;
  }

  .navbar .nav-link {
    color: var(--text-light);
    font-weight: 500;
    transition: all var(--transition-fast);
    padding: 0.5rem 1rem;
    border-radius: 6px;
  }

  .navbar .nav-link:hover {
    background-color: rgba(255, 255, 255, 0.15);
    transform: translateY(-1px);
  }

  .role-badge {
    background: rgba(255, 255, 255, 0.2);
    color: var(--text-light);
    padding: 0.35rem 0.75rem;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.5px;
    margin-right: 1rem;
    backdrop-filter: blur(4px);
    border: 1px solid rgba(255, 255, 255, 0.1);
  }

  /* COLLAPSIBLE SIDEBAR */
  .sidebar {
    position: fixed;
    top: 64px;
    left: 0;
    width: 80px;
    height: calc(100vh - 64px);
    background: var(--dark);
    transition: width var(--transition-normal);
    overflow-x: hidden;
    overflow-y: auto;
    z-index: 998;
    scrollbar-width: thin;
    scrollbar-color: var(--accent) transparent;
    box-shadow: var(--shadow-lg);
  }

  .sidebar:hover {
    width: 240px;
  }

  /* SIDEBAR NAV LINKS */
  .sidebar .nav {
    padding: 1rem 0.75rem;
  }

  .sidebar .nav-item {
    margin-bottom: 0.35rem;
    position: relative;
  }

  .sidebar .nav-link {
    color: var(--mid-gray);
    font-size: 0.875rem;
    padding: 0.75rem 1rem;
    display: flex;
    align-items: center;
    border-radius: 8px;
    transition: all var(--transition-fast);
    white-space: nowrap;
    position: relative;
    overflow: hidden;
  }

  .sidebar .nav-link i {
    min-width: 32px;
    text-align: center;
    margin-right: 0;
    transition: all var(--transition-normal);
    color: var(--mid-gray);
    font-size: 1.1rem;
  }

  .sidebar:hover .nav-link i {
    margin-right: 10px;
    color: var(--accent);
  }

  .sidebar .nav-link span {
    opacity: 0;
    transform: translateX(10px);
    transition: all var(--transition-normal);
    font-weight: 500;
  }

  .sidebar:hover .nav-link span {
    opacity: 1;
    transform: translateX(0);
  }

  .sidebar .nav-link:hover {
    background-color: rgba(255, 255, 255, 0.1);
    color: var(--text-light);
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
  }

  .sidebar .nav-link:hover i {
    color: var(--accent-light);
    transform: scale(1.1);
  }

  /* Active menu item */
  .sidebar .nav-link.active {
    background: linear-gradient(90deg, var(--primary-light), var(--secondary));
    color: var(--text-light);
    box-shadow: var(--shadow-md);
  }

  .sidebar .nav-link.active i {
    color: var(--text-light);
  }

  /* Menu item indicator */
  .sidebar .nav-link::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 3px;
    background: linear-gradient(to bottom, var(--accent), var(--accent-light));
    opacity: 0;
    transition: all var(--transition-fast);
  }

  .sidebar .nav-link.active::before {
    opacity: 1;
  }

  /* Menu categories */
  .menu-category {
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--accent);
    margin: 1.5rem 0 0.5rem 0.75rem;
    opacity: 0;
    transition: opacity var(--transition-normal);
    white-space: nowrap;
    font-weight: 600;
  }

  .sidebar:hover .menu-category {
    opacity: 0.8;
  }

  /* CONTENT WRAPPER */
  .content-wrapper {
    margin-top: 64px;
    margin-left: 80px;
    padding: 1.5rem;
    transition: margin-left var(--transition-normal);
  }

  .sidebar:hover ~ .content-wrapper {
    margin-left: 240px;
  }

  /* SCROLLBAR CUSTOMIZATION */
  .sidebar::-webkit-scrollbar {
    width: 4px;
  }

  .sidebar::-webkit-scrollbar-track {
    background: transparent;
  }

  .sidebar::-webkit-scrollbar-thumb {
    background-color: var(--accent);
    border-radius: 4px;
  }

  /* Mobile responsiveness */
  @media (max-width: 768px) {
    .sidebar {
      width: 0;
      box-shadow: none;
    }
    
    .sidebar.show {
      width: 240px;
      box-shadow: var(--shadow-lg);
    }
    
    .content-wrapper {
      margin-left: 0;
    }
    
    .sidebar:hover ~ .content-wrapper {
      margin-left: 0;
    }
    
    .sidebar.show ~ .content-wrapper {
      margin-left: 240px;
    }
    
    .mobile-toggle {
      display: block !important;
    }
  }

  /* Mobile menu toggle */
  .mobile-toggle {
    display: none;
    background: transparent;
    border: none;
    font-size: 1.25rem;
    color: var(--text-light);
    cursor: pointer;
    padding: 0.25rem 0.5rem;
    margin-right: 0.5rem;
  }

  /* User dropdown */
  .user-dropdown {
    display: flex;
    align-items: center;
  }

  .logout-btn {
    display: flex;
    align-items: center;
    background-color: rgba(255, 255, 255, 0.1);
    border-radius: 6px;
    padding: 0.5rem 1rem;
    transition: all var(--transition-fast);
  }

  .logout-btn:hover {
    background-color: rgba(255, 255, 255, 0.2);
    transform: translateY(-1px);
  }

  .logout-btn i {
    margin-right: 0.5rem;
  }

  /* Notification styles */
  .notification-item {
    transition: all var(--transition-fast);
    border-left: 3px solid transparent;
  }

  .notification-item:hover {
    background-color: var(--light-gray);
    border-left-color: var(--accent);
  }

  /* Dropdown menu improvements */
  .dropdown-menu {
    box-shadow: var(--shadow-lg);
    border: 1px solid var(--mid-gray);
    border-radius: 8px;
    position: absolute !important;
    z-index: 1000 !important;
    display: none;
  }
  
  .dropdown-menu.show {
    display: block !important;
  }

  .notification-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    position: sticky;
    top: 0;
    z-index: 1;
  }

  #notification-badge {
    transform: translate(-50%, -30%) !important;
  }
  
  /* Fix for dropdown */
  .dropdown-toggle::after {
    display: none;
  }
  
  .notification-bell {
    cursor: pointer;
    font-size: 1.2rem;
  }
  
  /* Custom notification dropdown */
  .notification-dropdown {
    width: 350px !important;
    max-height: 500px !important;
    overflow-y: auto !important;
    right: 0 !important;
    left: auto !important;
    padding: 0 !important;
    margin: 0.5rem 0 0 0 !important;
    transform: none !important;
  }
  
  /* Scrollbar for notification dropdown */
  .notification-dropdown::-webkit-scrollbar {
    width: 6px;
  }
  
  .notification-dropdown::-webkit-scrollbar-track {
    background: var(--light);
  }
  
  .notification-dropdown::-webkit-scrollbar-thumb {
    background-color: var(--accent);
    border-radius: 6px;
  }
  
  /* Notification body */
  .notification-body {
    max-height: 450px;
    overflow-y: auto;
  }
  
  .notification-body::-webkit-scrollbar {
    width: 6px;
  }
  
  .notification-body::-webkit-scrollbar-track {
    background: var(--light);
  }
  
  .notification-body::-webkit-scrollbar-thumb {
    background-color: var(--accent);
    border-radius: 6px;
  }
</style>

</head>
<body>
<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid px-0">
    <button class="mobile-toggle d-lg-none" type="button" id="sidebarToggle">
      <i class="fas fa-bars"></i>
    </button>
    <a class="navbar-brand" href="dashboard.php">
      <i class="fas fa-cubes"></i>
      <span>DIGITAL STOCK</span>
    </a>
    <ul class="navbar-nav ms-auto">
      <li class="nav-item dropdown">
        <!-- IMPORTANT: Removed the href attribute that was causing navigation -->
        <a class="nav-link position-relative dropdown-toggle notification-bell" href="#" id="notificationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="fas fa-bell"></i>
          <span id="notification-badge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.5rem; padding: 0.25rem 0.4rem;">
            <span id="notification-count">0</span>
            <span class="visually-hidden">unread notifications</span>
          </span>
        </a>
        <div class="dropdown-menu notification-dropdown" aria-labelledby="notificationDropdown">
          <div class="notification-header bg-primary text-white p-2">
            <h6 class="m-0"><i class="fas fa-exclamation-triangle me-2"></i>Stock Alerts</h6>
          </div>
          <div id="notification-list" class="notification-body">
            <!-- Loading placeholder -->
            <div class="text-center py-4 text-muted">
              <i class="fas fa-spinner fa-spin mb-2"></i>
              <p class="mb-0">Loading notifications...</p>
            </div>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <span class="role-badge"><?php echo $roleText; ?></span>
      </li>
      <li class="nav-item">
        <a class="nav-link logout-btn" href="../logout.php">
          <i class="fas fa-sign-out-alt"></i>Logout
        </a>
      </li>
    </ul>
  </div>
</nav>

<!-- COLLAPSIBLE SIDEBAR -->
<div class="sidebar" id="sidebar">
  <ul class="nav flex-column">
    <div class="menu-category">Dashboard</div>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'dashboard.php') ? 'active' : ''; ?>" href="dashboard.php">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
      </a>
    </li>
    
    <div class="menu-category">Inventory</div>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'category.php') ? 'active' : ''; ?>" href="category.php">
        <i class="fas fa-list"></i>
        <span>Categories</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'brand.php') ? 'active' : ''; ?>" href="brand.php">
        <i class="fas fa-tags"></i>
        <span>Brands</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'product.php') ? 'active' : ''; ?>" href="product.php">
        <i class="fas fa-box-open"></i>
        <span>Products</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'suppliers.php') ? 'active' : ''; ?>" href="suppliers.php">
        <i class="fas fa-truck"></i>
        <span>Suppliers</span>
      </a>
    </li>
    
    <div class="menu-category">Sales</div>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'order.php') ? 'active' : ''; ?>" href="order.php">
        <i class="fas fa-shopping-cart"></i>
        <span>Sales Invoice</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'order_list.php') ? 'active' : ''; ?>" href="order_list.php">
        <i class="fas fa-file-invoice"></i>
        <span>Sales List</span>
      </a>
    </li>
    
    <div class="menu-category">Purchasing</div>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'purchase_order.php') ? 'active' : ''; ?>" href="purchase_order.php">
        <i class="fas fa-shopping-bag"></i>
        <span>Purchase</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'list_purchase_order.php') ? 'active' : ''; ?>" href="list_purchase_order.php">
        <i class="fas fa-clipboard-list"></i>
        <span>Purchase List</span>
      </a>
    </li>
    
    <div class="menu-category">Administration</div>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'users.php') ? 'active' : ''; ?>" href="users.php">
        <i class="fas fa-users"></i>
        <span>User Management</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'reports.php') ? 'active' : ''; ?>" href="reports.php">
        <i class="fas fa-chart-line"></i>
        <span>Reports</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php echo ($currentPage == 'profile.php') ? 'active' : ''; ?>" href="profile.php">
        <i class="fas fa-user"></i>
        <span>Profile</span>
      </a>
    </li>
  </ul>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom JS -->
<script>
  // Mobile sidebar toggle
  document.addEventListener('DOMContentLoaded', function() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    
    if (sidebarToggle) {
      sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('show');
      });
    }
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(event) {
      const isClickInsideSidebar = sidebar.contains(event.target);
      const isClickInsideToggle = sidebarToggle && sidebarToggle.contains(event.target);
      
      if (!isClickInsideSidebar && !isClickInsideToggle && window.innerWidth < 768 && sidebar.classList.contains('show')) {
        sidebar.classList.remove('show');
      }
    });
    
    // Handle window resize
    window.addEventListener('resize', function() {
      if (window.innerWidth >= 768) {
        sidebar.classList.remove('show');
      }
    });

    // Add animation to menu items
    const menuItems = document.querySelectorAll('.sidebar .nav-link');
    menuItems.forEach((item, index) => {
      item.style.transitionDelay = `${index * 0.05}s`;
    });
    
    // Explicitly initialize the notification dropdown
    const notificationDropdown = document.getElementById('notificationDropdown');
    if (notificationDropdown) {
      const dropdown = new bootstrap.Dropdown(notificationDropdown);
      
      // Manual toggle for the dropdown
      notificationDropdown.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        dropdown.toggle();
        
        // Load notifications when dropdown is opened
        if (notificationDropdown.getAttribute('aria-expanded') === 'false') {
          loadNotifications();
        }
      });
    }
    
    // Initial load of notification count
    loadNotificationCount();
    
    // Generate test notifications for demonstration
    generateTestNotifications();
  });

  // Function to generate test notifications
  function generateTestNotifications() {
    const testData = [
      { product_name: "Laptop Dell XPS 13", quantity: 3 },
      { product_name: "iPhone 13 Pro", quantity: 2 },
      { product_name: "Samsung Galaxy S22", quantity: 0 },
      { product_name: "HP Printer Ink Cartridge", quantity: 1 },
      { product_name: "Logitech MX Master Mouse", quantity: 4 },
      { product_name: "Apple AirPods Pro", quantity: 0 },
      { product_name: "Microsoft Surface Pro", quantity: 2 },
      { product_name: "Sony WH-1000XM4 Headphones", quantity: 1 },
      { product_name: "Canon EOS R5 Camera", quantity: 0 },
      { product_name: "LG 4K Monitor", quantity: 3 }
    ];
    
    // Update notification count
    const notificationCount = document.getElementById('notification-count');
    if (notificationCount) {
      notificationCount.textContent = testData.length;
      
      // Show badge
      const badge = document.getElementById('notification-badge');
      if (badge) {
        badge.style.display = 'block';
      }
    }
    
    // Store test data for later use
    window.testNotificationData = testData;
  }

  // Function to load notifications
  function loadNotifications() {
    console.log('Loading notifications');
    const notificationList = document.getElementById('notification-list');
    
    // Show loading indicator
    notificationList.innerHTML = `
      <div class="text-center py-4 text-muted">
        <i class="fas fa-spinner fa-spin mb-2"></i>
        <p class="mb-0">Loading notifications...</p>
      </div>
    `;
    
    // Use test data instead of fetch for demonstration
    setTimeout(() => {
      if (window.testNotificationData) {
        updateNotificationList(window.testNotificationData);
      } else {
        // Fallback to fetch if no test data
        fetch('fetch_low_stock.php')
          .then(response => {
            console.log('Response received:', response);
            return response.json();
          })
          .then(data => {
            console.log('Data received:', data);
            updateNotificationList(data);
          })
          .catch(error => {
            console.error('Error fetching notifications:', error);
            notificationList.innerHTML = `
              <div class="text-center py-4 text-danger">
                <i class="fas fa-exclamation-circle fa-2x mb-2"></i>
                <p class="mb-0">Error loading notifications.</p>
                <small>Please try again later.</small>
              </div>
            `;
          });
      }
    }, 500); // Simulate loading delay
  }

  // Function to update notification list
  function updateNotificationList(data) {
    const notificationList = document.getElementById('notification-list');
    
    if (data.length > 0) {
      // Clear loading message
      notificationList.innerHTML = '';
      
      // Add each low stock item to the notification list
      data.forEach(item => {
        const statusClass = item.quantity === 0 ? 'danger' : 'warning';
        const statusText = item.quantity === 0 ? 'Out of Stock' : 'Low Stock';
        const statusIcon = item.quantity === 0 ? 'fa-times-circle' : 'fa-exclamation-triangle';
        
        const notificationItem = document.createElement('div');
        notificationItem.className = 'notification-item p-3 border-bottom';
        notificationItem.innerHTML = `
          <div class="d-flex align-items-center">
            <div class="flex-shrink-0">
              <i class="fas ${statusIcon} text-${statusClass} fa-lg"></i>
            </div>
            <div class="flex-grow-1 ms-3">
              <h6 class="mb-1">${item.product_name}</h6>
              <p class="mb-0 text-${statusClass} small">
                <strong>${statusText}:</strong> ${item.quantity} units remaining
              </p>
            </div>
          </div>
        `;
        notificationList.appendChild(notificationItem);
      });
      
      // Add "View All" button at the bottom
      const viewAllButton = document.createElement('div');
      viewAllButton.className = 'text-center p-2 bg-light';
      viewAllButton.innerHTML = `
        <a href="product.php?filter=low_stock" class="btn btn-sm btn-primary">
          <i class="fas fa-eye me-1"></i> View All Low Stock Items
        </a>
      `;
      notificationList.appendChild(viewAllButton);
      
    } else {
      // No low stock items
      notificationList.innerHTML = `
        <div class="text-center py-4 text-muted">
          <i class="fas fa-check-circle fa-2x mb-2"></i>
          <p class="mb-0">No stock alerts at this time.</p>
        </div>
      `;
    }
  }

  // Function to load notification count
  function loadNotificationCount() {
    console.log('Loading notification count');
    
    // Use test data for demonstration
    if (window.testNotificationData) {
      const notificationCount = document.getElementById('notification-count');
      if (notificationCount) {
        notificationCount.textContent = window.testNotificationData.length;
        
        // Show badge if there are notifications
        const badge = document.getElementById('notification-badge');
        if (badge) {
          badge.style.display = window.testNotificationData.length > 0 ? 'block' : 'none';
        }
      }
    } else {
      // Fallback to fetch if no test data
      fetch('fetch_low_stock.php')
        .then(response => response.json())
        .then(data => {
          const notificationCount = document.getElementById('notification-count');
          if (notificationCount) {
            notificationCount.textContent = data.length;
            
            // Hide badge if no notifications
            const badge = document.getElementById('notification-badge');
            if (badge) {
              badge.style.display = data.length > 0 ? 'block' : 'none';
            }
          }
        })
        .catch(error => {
          console.error('Error fetching notification count:', error);
        });
    }
  }
</script>
</body>
</html>
