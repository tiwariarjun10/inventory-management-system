<?php
session_start();
require_once '../db.php'; // your DB connection

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = $conn->real_escape_string($_POST['customer_name']);
    $contact       = $conn->real_escape_string($_POST['contact']);
    $order_date    = $conn->real_escape_string($_POST['order_date']);
    $vat           = (float)$_POST['vat'];
    $discount      = (float)$_POST['discount'];
    $items_json    = $_POST['items_json'];
    $items         = json_decode($items_json, true) ?: [];

    // Server-side contact validation
    if (!preg_match('/^9\d{9}$/', $contact)) {
        $message = '<div class="alert alert-danger">Invalid contact number! It must be exactly 10 digits and start with 9.</div>';
    } elseif (empty($items)) {
        $message = '<div class="alert alert-danger">Please add at least one product.</div>';
    } else {
        // calculate subtotal
        $subTotal = 0;
        foreach ($items as $it) {
            $pid = (int)$it['product_id'];
            $qty = (int)$it['quantity'];
            $row = $conn->query("SELECT price FROM products WHERE id = $pid")->fetch_assoc();
            $subTotal += $row['price'] * $qty;
        }
        $vatAmt    = $subTotal * ($vat/100);
        $discAmt   = $subTotal * ($discount/100);
        $total     = $subTotal + $vatAmt - $discAmt;

        // insert order
        $sql = "
          INSERT INTO orders 
            (customer_name, contact, order_date, vat, discount, total_amount, status)
          VALUES 
            ('$customer_name','$contact','$order_date',$vat,$discount,$total,'pending')
        ";
        if ($conn->query($sql)) {
            $order_id = $conn->insert_id;
            foreach ($items as $it) {
                $pid = (int)$it['product_id'];
                $qty = (int)$it['quantity'];
                $price = $conn->query("SELECT price FROM products WHERE id=$pid")->fetch_assoc()['price'];
                $line  = $price * $qty;
                $conn->query("
                  INSERT INTO order_items 
                    (order_id, product_id, quantity, line_total)
                  VALUES 
                    ($order_id,$pid,$qty,$line)
                ");
            }
            $message = '<div class="alert alert-success">Order created successfully.</div>';
        } else {
            $message = '<div class="alert alert-danger">Error: '.$conn->error.'</div>';
        }
    }
}

// fetch products for dropdown
$prods = $conn->query("SELECT id,name FROM products ORDER BY name");
$options = '';
while ($p = $prods->fetch_assoc()) {
    $options .= "<option value=\"{$p['id']}\">".htmlspecialchars($p['name'])."</option>";
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Create Sales Order</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">
<?php include_once("navbar-sidebar.php"); ?>
<div class="content-wrapper p-4">
  <h2>New Sales Order</h2>
  <?= $message ?>

  <form method="post" id="orderForm" class="bg-white p-4 rounded shadow">
    <!-- customer details -->
    <div class="form-row">
      <div class="form-group col-md-6">
        <label>Customer Name</label>
        <input name="customer_name" class="form-control" required>
      </div>
      <div class="form-group col-md-6">
        <label>Contact</label>
        <input name="contact" class="form-control" required
               pattern="9\d{9}" maxlength="10" title="Must be 10 digits and start with 9">
      </div>
    </div>
    <div class="form-group">
      <label>Order Date</label>
      <input type="date" name="order_date" class="form-control" value="<?=date('Y-m-d')?>" required>
    </div>

    <!-- items -->
    <h5>Items</h5>
    <table class="table table-bordered" id="itemsTable">
      <thead><tr><th>Product</th><th>Qty</th><th>Action</th></tr></thead>
      <tbody></tbody>
    </table>
    <button type="button" class="btn btn-sm btn-info mb-3" onclick="addRow()">+ Add Item</button>
    <input type="hidden" name="items_json" id="items_json">

    <!-- VAT/Discount -->
    <div class="form-row">
      <div class="form-group col-md-6">
        <label>VAT (%)</label>
        <input type="number" id="vat" name="vat" class="form-control" value="13" required>
      </div>
      <div class="form-group col-md-6">
        <label>Discount (%)</label>
        <input type="number" id="discount" name="discount" class="form-control" value="0">
      </div>
    </div>
    <div class="form-group">
      <label>Total</label>
      <input type="text" id="total_amount" class="form-control" readonly value="0.00">
    </div>

    <button type="submit" class="btn btn-primary">Create Order</button>
  </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
let opts = `<?= $options ?>`;

function addRow() {
  $('#itemsTable tbody').append(`
    <tr>
      <td><select class="form-control product_id">${opts}</select></td>
      <td><input type="number" class="form-control quantity" min="1" value="1"></td>
      <td><button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">×</button></td>
    </tr>`);
  updateTotal();
}

function removeRow(btn) {
  $(btn).closest('tr').remove();
  updateTotal();
}

$(document).on('change input', '.product_id, .quantity, #vat, #discount', updateTotal);

function updateTotal() {
  let sub = 0, items = [];
  $('#itemsTable tbody tr').each(function () {
    let pid = $(this).find('.product_id').val();
    let q = +$(this).find('.quantity').val();
    if (pid && q > 0) {
      $.ajax({
        url: 'fetch_product_price.php',
        data: {product_id: pid},
        async: false,
        success(r) {
          let p = +r || 0;
          sub += p * q;
          items.push({product_id: pid, quantity: q});
        }
      });
    }
  });
  $('#items_json').val(JSON.stringify(items));
  let vat = +$('#vat').val(), d = +$('#discount').val();
  $('#total_amount').val((sub + sub * vat / 100 - sub * d / 100).toFixed(2));
}

$('#orderForm').on('submit', function (e) {
  if ($('#items_json').val() === '[]') {
    e.preventDefault();
    alert('Add at least one item');
  }
});
</script>
</body>
</html>
