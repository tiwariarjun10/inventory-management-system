<?php
session_start();
require_once '../db.php'; // Adjust path if needed

$name = $contact_person = $phone = $email = $address = '';
$errors = [];
$isEdit = false;
$editId = null;

function s($str) {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

// Delete
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    $conn->query("DELETE FROM suppliers WHERE id = $delId");
    $_SESSION['flash_success'] = "Supplier #$delId deleted.";
    header("Location: suppliers.php");
    exit();
}

// Edit
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $res = $conn->query("SELECT * FROM suppliers WHERE id = $editId");
    if ($row = $res->fetch_assoc()) {
        $isEdit = true;
        $name = $row['name'];
        $contact_person = $row['contact_person'];
        $phone = $row['phone'];
        $email = $row['email'];
        $address = $row['address'];
    } else {
        $_SESSION['flash_error'] = "Supplier not found.";
        header("Location: suppliers.php");
        exit();
    }
}

// Add/Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name           = s($_POST['name'] ?? '');
    $contact_person = s($_POST['contact_person'] ?? '');
    $phone          = s($_POST['phone'] ?? '');
    $email          = s($_POST['email'] ?? '');
    $address        = s($_POST['address'] ?? '');
    $editId         = isset($_POST['edit_id']) ? (int)$_POST['edit_id'] : null;
    $isEdit         = $editId !== null;

    // Validation
    if ($name === '') $errors['name'] = 'Name is required.';
    if ($phone === '') {
        $errors['phone'] = 'Phone is required.';
    } elseif (!preg_match('/^9\d{9}$/', $phone)) {
        $errors['phone'] = 'Phone must start with 9 and be 10 digits.';
    }
    if ($email === '') {
        $errors['email'] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format.';
    } elseif (preg_match('/^[0-9]+@gmail\.com$/', $email)) {
        // This will catch emails like 123@gmail.com, 456@gmail.com, etc.
        $errors['email'] = 'Numeric-only usernames are not allowed.';
    } elseif (strpos($email, ';') !== false) {
        // This will catch emails with semicolons like 456@gmai;.com
        $errors['email'] = 'Email contains invalid characters.';
    }

    if (empty($errors)) {
        if ($isEdit) {
            $stmt = $conn->prepare("UPDATE suppliers SET name=?, contact_person=?, phone=?, email=?, address=? WHERE id=?");
            $stmt->bind_param('sssssi', $name, $contact_person, $phone, $email, $address, $editId);
            $stmt->execute();
            $_SESSION['flash_success'] = "Supplier #$editId updated.";
        } else {
            $stmt = $conn->prepare("INSERT INTO suppliers (name, contact_person, phone, email, address) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param('sssss', $name, $contact_person, $phone, $email, $address);
            $stmt->execute();
            $newId = $stmt->insert_id;
            $_SESSION['flash_success'] = "Supplier #$newId added.";
        }
        header("Location: suppliers.php");
        exit();
    }
}

// Fetch all
$suppliers = $conn->query("SELECT * FROM suppliers ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Management | Digital Stock</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--mid-gray);
        }

        .page-title {
            font-weight: 600;
            color: var(--primary);
            font-size: 1.5rem;
            margin: 0;
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            border: none;
            margin-bottom: 1.5rem;
        }

        .card-header {
            background: linear-gradient(to right, var(--primary-light), var(--secondary));
            color: white;
            border-radius: 12px 12px 0 0 !important;
            padding: 1rem 1.25rem;
            font-weight: 600;
        }

        .card-body {
            padding: 1.5rem;
        }

        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid var(--mid-gray);
            padding: 0.6rem 1rem;
            font-size: 0.95rem;
            box-shadow: var(--shadow-sm);
            transition: all var(--transition-fast);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(87, 197, 182, 0.25);
        }

        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.25rem;
            font-weight: 500;
            transition: all var(--transition-fast);
        }

        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-warning {
            background-color: var(--warning);
            border-color: var(--warning);
            color: white;
        }

        .btn-warning:hover {
            background-color: #e08e0b;
            border-color: #e08e0b;
            color: white;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-danger {
            background-color: var(--danger);
            border-color: var(--danger);
        }

        .btn-danger:hover {
            background-color: #dc2626;
            border-color: #dc2626;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-secondary {
            background-color: var(--text-muted);
            border-color: var(--text-muted);
        }

        .btn-secondary:hover {
            background-color: var(--text-dark);
            border-color: var(--text-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-sm {
            padding: 0.4rem 0.75rem;
            font-size: 0.85rem;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: var(--primary);
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: none;
            padding: 0.75rem 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-color: var(--mid-gray);
            font-size: 0.95rem;
        }

        .table tbody tr:hover {
            background-color: rgba(87, 197, 182, 0.05);
        }

        .alert {
            border-radius: 8px;
            box-shadow: var(--shadow-sm);
            border: none;
        }

        .alert-success {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        .alert-danger {
            background-color: rgba(239, 68, 68, 0.15);
            color: var(--danger);
        }

        .form-label {
            font-weight: 500;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .error {
            color: var(--danger);
            font-size: 0.85rem;
            margin-top: 0.25rem;
        }
    </style>
</head>
<body>
<?php include_once("navbar-sidebar.php"); ?>

<div class="content-wrapper">
    <div class="page-header">
        <h1 class="page-title">Supplier Management</h1>
    </div>

    <div class="row">
        <!-- Form Section -->
        <div class="col-md-5">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-<?php echo $isEdit ? 'edit' : 'plus-circle'; ?> me-2"></i>
                    <?php echo $isEdit ? "Edit Supplier #$editId" : 'Add New Supplier'; ?>
                </div>
                <div class="card-body">
                    <!-- Flash Messages -->
                    <?php if (!empty($_SESSION['flash_success'])): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($_SESSION['flash_error'])): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?php echo $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?>
                        </div>
                    <?php endif; ?>

                    <form method="post" novalidate>
                        <?php if ($isEdit): ?>
                            <input type="hidden" name="edit_id" value="<?php echo $editId; ?>">
                        <?php endif; ?>

                        <div class="form-group mb-3">
                            <label for="name" class="form-label">Company Name *</label>
                            <input type="text" id="name" name="name" class="form-control" value="<?php echo $name; ?>" required>
                            <?php if (isset($errors['name'])): ?>
                                <div class="error"><?php echo $errors['name']; ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group mb-3">
                            <label for="contact_person" class="form-label">Contact Person</label>
                            <input type="text" id="contact_person" name="contact_person" class="form-control" value="<?php echo $contact_person; ?>">
                        </div>

                        <div class="form-group mb-3">
                            <label for="phone" class="form-label">Phone Number *</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                <input type="text" id="phone" name="phone" class="form-control" value="<?php echo $phone; ?>" pattern="9\d{9}" title="Must start with 9 and be 10 digits">
                            </div>
                            <?php if (isset($errors['phone'])): ?>
                                <div class="error"><?php echo $errors['phone']; ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group mb-3">
                            <label for="email" class="form-label">Email Address *</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" id="email" name="email" class="form-control" value="<?php echo $email; ?>" 
                                       required pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$" 
                                       title="Please enter a valid email address">
                            </div>
                            <?php if (isset($errors['email'])): ?>
                                <div class="error"><?php echo $errors['email']; ?></div>
                            <?php endif; ?>
                            <small class="text-muted">Example: supplier@company.com</small>
                        </div>

                        <div class="form-group mb-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea id="address" name="address" class="form-control" rows="3"><?php echo $address; ?></textarea>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-<?php echo $isEdit ? 'warning' : 'primary'; ?>">
                                <i class="fas fa-<?php echo $isEdit ? 'save' : 'plus-circle'; ?> me-2"></i>
                                <?php echo $isEdit ? 'Update Supplier' : 'Add Supplier'; ?>
                            </button>
                            <?php if ($isEdit): ?>
                                <a href="suppliers.php" class="btn btn-secondary">
                                    <i class="fas fa-times me-2"></i> Cancel
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Table Section -->
        <div class="col-md-7">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-truck me-2"></i> Supplier List
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Contact</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($suppliers->num_rows > 0): ?>
                                    <?php while ($row = $suppliers->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo s($row['name']); ?></td>
                                            <td><?php echo s($row['contact_person']); ?></td>
                                            <td><?php echo s($row['phone']); ?></td>
                                            <td><?php echo s($row['email']); ?></td>
                                            <td>
                                                <a href="suppliers.php?edit=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="suppliers.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this supplier?');" class="btn btn-danger btn-sm">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4">No suppliers found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
