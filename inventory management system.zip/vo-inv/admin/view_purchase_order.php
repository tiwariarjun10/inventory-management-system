<?php
session_start();
require_once '../db.php';

// Check database connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Validate order ID
$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($order_id <= 0) {
    die("Invalid order ID");
}

// Fetch purchase order details
$order = [];
$sql_order = "SELECT po.id, s.name AS supplier_name, po.total_amount, 
             po.status, po.created_at, po.received_at
             FROM purchase_orders po
             JOIN suppliers s ON po.supplier_id = s.id
             WHERE po.id = ?";

// Prepare and validate first statement
$stmt_order = $conn->prepare($sql_order);
if (!$stmt_order) {
    die("Error preparing order statement: " . $conn->error);
}

$stmt_order->bind_param("i", $order_id);
if (!$stmt_order->execute()) {
    die("Error executing order query: " . $stmt_order->error);
}

$result_order = $stmt_order->get_result();
if ($result_order->num_rows === 0) {
    die("Purchase order not found");
}
$order = $result_order->fetch_assoc();
$stmt_order->close();

// Fetch purchased items
$items = [];
$sql_items = "SELECT p.name AS product_name, pi.quantity, 
             pi.price, pi.line_total
             FROM purchase_items pi
             JOIN products p ON pi.product_id = p.id
             WHERE pi.purchase_id = ?"; // Verify column name matches your DB

// Prepare and validate second statement
$stmt_items = $conn->prepare($sql_items);
if (!$stmt_items) {
    die("Error preparing items statement: " . $conn->error);
}

$stmt_items->bind_param("i", $order_id); // This was line 54
if (!$stmt_items->execute()) {
    die("Error executing items query: " . $stmt_items->error);
}

$result_items = $stmt_items->get_result();
$items = $result_items->fetch_all(MYSQLI_ASSOC);
$stmt_items->close();
?>