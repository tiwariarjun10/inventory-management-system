<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
  header("Location: ../login.php");
  exit();
}
require_once '../db.php';

// Add customer
if (isset($_POST['add_customer'])) {
  $name    = $conn->real_escape_string($_POST['name']);
  $email   = $conn->real_escape_string($_POST['email']);
  $phone   = $conn->real_escape_string($_POST['phone']);
  $address = $conn->real_escape_string($_POST['address']);

  $conn->query("
    INSERT INTO customers (name, email, phone, address)
    VALUES ('$name', '$email', '$phone', '$address')
  ");
  header("Location: customers.php");
  exit();
}

// Delete customer
if (isset($_GET['delete'])) {
  $deleteId = (int)$_GET['delete'];
  $conn->query("DELETE FROM customers WHERE id=$deleteId");
  header("Location: customers.php");
  exit();
}

// List customers
$customers = $conn->query("SELECT * FROM customers ORDER BY id DESC");
?>
<html>
<head>
  <title>Customer Management</title>
   <!-- Include CSS/Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
  <!-- admin navbar/sidebar -->
  <div class="container mt-4">
    <h1>Customers</h1>

    <form method="post" class="mb-4">
      <div class="form-row">
        <div class="col">
          <input type="text" name="name" class="form-control" placeholder="Customer Name" required>
        </div>
        <div class="col">
          <input type="email" name="email" class="form-control" placeholder="Email">
        </div>
        <div class="col">
          <input type="text" name="phone" class="form-control" placeholder="Phone">
        </div>
      </div>
      <div class="form-group mt-2">
        <textarea name="address" class="form-control" placeholder="Address"></textarea>
      </div>
      <button type="submit" name="add_customer" class="btn btn-primary">Add Customer</button>
    </form>

    <table class="table table-bordered table-striped">
      <thead class="thead-dark">
        <tr>
          <th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>Action</th>
        </tr>
      </thead>
      <tbody>
      <?php while($row = $customers->fetch_assoc()): ?>
        <tr>
          <td><?php echo $row['id']; ?></td>
          <td><?php echo $row['name']; ?></td>
          <td><?php echo $row['email']; ?></td>
          <td><?php echo $row['phone']; ?></td>
          <td><?php echo $row['address']; ?></td>
          <td>
            <a href="customers.php?delete=<?php echo $row['id']; ?>" 
               class="btn btn-danger btn-sm"
               onclick="return confirm('Delete this customer?');">
               Delete
            </a>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
