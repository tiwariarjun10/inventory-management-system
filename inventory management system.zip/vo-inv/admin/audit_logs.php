<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
  header("Location: ../login.php");
  exit();
}
require_once '../db.php';

$logs = $conn->query("
  SELECT a.*, u.username 
  FROM audit_logs a 
  LEFT JOIN users u ON a.user_id = u.id 
  ORDER BY a.log_time DESC
");
?>
<html>
<head>
  <title>Audit Logs</title>
  <!-- Include your CSS/Bootstrap -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
  <!-- Include your admin navbar/sidebar -->
  <div class="container">
    <h1>Audit Logs</h1>
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Action</th>
          <th>Time</th>
        </tr>
      </thead>
      <tbody>
      <?php while ($row = $logs->fetch_assoc()) { ?>
        <tr>
          <td><?php echo $row['id']; ?></td>
          <td><?php echo $row['username']; ?></td>
          <td><?php echo $row['action']; ?></td>
          <td><?php echo $row['log_time']; ?></td>
        </tr>
      <?php } ?>
      </tbody>
    </table>
  </div>
</body>
</html>
