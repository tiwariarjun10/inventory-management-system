<?php
require_once '../db.php';
$query = $_GET['query'];
$searchQuery = $conn->query("SELECT * FROM users WHERE username LIKE '%$query%' OR id = '$query'");
if ($searchQuery->num_rows > 0) {
    echo "<table class='table table-bordered'><tr><th>ID</th><th>Username</th><th>Role</th><th>Email</th></tr>";
    while ($row = $searchQuery->fetch_assoc()) {
        echo "<tr><td>{$row['id']}</td><td>{$row['username']}</td><td>{$row['role']}</td><td>{$row['email']}</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p class='text-danger'>No results found</p>";
}
?>
 
 // serching employee function and dark mode function
 <!-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    function toggleDarkMode() {
        document.body.classList.toggle('dark-mode');
        
        let isDark = document.body.classList.contains('dark-mode');
        
        // Store dark mode setting in localStorage
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        
        // Update button text
        document.getElementById('darkModeBtn').innerText = isDark ? 'Light Mode' : 'Dark Mode';
    }

    // Apply saved dark mode preference on page load
    window.onload = function () {
        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-mode');
            document.getElementById('darkModeBtn').innerText = 'Light Mode';
        }
    };

    function searchEmployee() {
        let query = $('#searchEmployee').val();
        if (query.trim() !== '') {
            $.ajax({
                url: 'search_employee.php',
                method: 'GET',
                data: { query: query },
                success: function (response) {
                    $('#searchResults').html(response);
                }
            });
        }
    }
</script>  -->