<?php
session_start();
require_once '../db.php'; // adjust path to your DB connection

$message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $supplier_id = (int)$_POST['supplier_id'];
    $order_date  = $conn->real_escape_string($_POST['order_date']);
    $vat         = isset($_POST['vat']) ? (float)$_POST['vat'] : 0;
    $discount    = isset($_POST['discount']) ? (float)$_POST['discount'] : 0;
    $items_json  = isset($_POST['items_json']) ? $_POST['items_json'] : '[]';

    $items = json_decode($items_json, true) ?: [];

    if (empty($items)) {
        $message = '<div class="alert alert-danger">No items were selected.</div>';
    } else {
        $subTotal = 0;
        // Calculate subtotal
        foreach ($items as $item) {
            $pid = (int)$item['product_id'];
            $qty = (int)$item['quantity'];
            // Fetch price
            $res = $conn->query("SELECT price FROM products WHERE id=$pid");
            if ($res && $row = $res->fetch_assoc()) {
                $subTotal += $row['price'] * $qty;
            }
        }
        // VAT and discount
        $vatAmount      = $subTotal * ($vat / 100);
        $discountAmount = $subTotal * ($discount / 100);
        $totalAmount    = $subTotal + $vatAmount - $discountAmount;

        // Insert purchase order
        $sql = "INSERT INTO purchase_orders (supplier_id, order_date, vat, discount, total_amount) 
                VALUES ($supplier_id, '$order_date', $vat, $discount, $totalAmount)";
        if ($conn->query($sql)) {
            $order_id = $conn->insert_id;
            // Insert items and update stock
            foreach ($items as $item) {
                $pid = (int)$item['product_id'];
                $qty = (int)$item['quantity'];
                // fetch price
                $res = $conn->query("SELECT price FROM products WHERE id=$pid");
                $price = ($res && $r = $res->fetch_assoc()) ? (float)$r['price'] : 0;
                $lineTotal = $price * $qty;
                // update stock (increase)
                $conn->query("UPDATE products SET quantity = quantity + $qty WHERE id=$pid");
                // insert purchase item
                $conn->query("INSERT INTO purchase_order_items (purchase_order_id, product_id, quantity, line_total) 
                              VALUES ($order_id, $pid, $qty, $lineTotal)");
            }
            $message = '<div class="alert alert-success">Purchase order placed! Stock updated. Total: $'.number_format($totalAmount,2).' </div>';
        } else {
            $message = '<div class="alert alert-danger">Error: '.$conn->error.'</div>';
        }
    }
}

// Fetch suppliers options
$supRes = $conn->query("SELECT id, name FROM suppliers ORDER BY name ASC");
$supOptions = '';
while ($s = $supRes->fetch_assoc()) {
    $supOptions .= '<option value="'.$s['id'].'">'.htmlspecialchars($s['name']).'</option>';
}
// Fetch products options
$prdRes = $conn->query("SELECT id, name FROM products ORDER BY name ASC");
$prdOptions = '';
while ($p = $prdRes->fetch_assoc()) {
    $prdOptions .= '<option value="'.$p['id'].'">'.htmlspecialchars($p['name']).'</option>';
}
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Purchase Order</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">
<?php include_once('navbar-sidebar.php'); ?>
<div class="content-wrapper mt-5">
    <h2>Purchase Order</h2>
    <?php echo $message; ?>
    <form method="POST" id="purchaseForm" class="bg-white p-4 rounded shadow-sm">
        <div class="form-group">
            <label>Supplier</label>
            <select name="supplier_id" class="form-control" required>
                <option value="">-- Select Supplier --</option>
                <?php echo $supOptions; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Order Date</label>
            <input type="date" name="order_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
        </div>
        <hr>
        <h4>Items</h4>
        <table class="table table-bordered" id="itemsTable">
            <thead class="thead-dark">
                <tr><th>Product</th><th>Quantity</th><th>Action</th></tr>
            </thead>
            <tbody></tbody>
        </table>
        <button type="button" class="btn btn-info btn-sm mb-3" onclick="addRow()">+ Add Item</button>
        <input type="hidden" name="items_json" id="items_json">
        <div class="form-group">
            <label>VAT (%)</label>
            <input type="number" id="vat" name="vat" class="form-control" value="13" required>
        </div>
        <div class="form-group">
            <label>Discount (%)</label>
            <input type="number" id="discount" name="discount" class="form-control" value="0">
        </div>
        <div class="form-group">
            <label>Total Amount</label>
            <input type="text" id="total_amount" class="form-control" value="0.00" readonly>
        </div>
        <button type="submit" class="btn btn-primary">Place Order</button>
    </form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
let prdOptions = `<?php echo $prdOptions; ?>`;
function addRow() {
    $('#itemsTable tbody').append(`
      <tr>
        <td><select class="form-control product_id" required>${prdOptions}</select></td>
        <td><input type="number" class="form-control quantity" min="1" value="1" required></td>
        <td><button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">Remove</button></td>
      </tr>
    `);
}
function removeRow(btn) { $(btn).closest('tr').remove(); updateTotal(); }
$(document).on('change input', '.product_id, .quantity, #vat, #discount', updateTotal);
function updateTotal() {
    let items = [], sub = 0;
    $('#itemsTable tbody tr').each(function() {
        let pid = $(this).find('.product_id').val(), qty = +$(this).find('.quantity').val();
        if (pid && qty>0) {
            $.ajax({url:'fetch_product_price.php', data:{product_id:pid}, async:false,
                success:function(r){ let p=+r||0; sub+=p*qty; items.push({product_id:pid,quantity:qty}); }
            });
        }
    });
    $('#items_json').val(JSON.stringify(items));
    let vat=+$('#vat').val(), disc=+$('#discount').val();
    let total=sub + sub*(vat/100) - sub*(disc/100);
    $('#total_amount').val(total.toFixed(2));
}
$('#purchaseForm').on('submit', function(e){updateTotal(); if($('#items_json').val()=='[]'){e.preventDefault();alert('Add items.');}});
</script>
</body>
</html>
