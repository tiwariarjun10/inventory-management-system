<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
  header("Location: ../login.php");
  exit();
}
require_once '../db.php';

// List products with (if any) inventory quantity
$products = $conn->query("SELECT p.*, i.quantity 
                          FROM products p 
                          LEFT JOIN inventory i ON p.id = i.product_id");

if(isset($_POST['update_inventory'])){
  $product_id = (int)$_POST['product_id'];
  $quantity   = (int)$_POST['quantity'];
  // Check if an inventory record exists
  $check = $conn->query("SELECT * FROM inventory WHERE product_id=$product_id");
  if($check->num_rows > 0){
    $conn->query("UPDATE inventory SET quantity=$quantity WHERE product_id=$product_id");
  } else {
    $conn->query("INSERT INTO inventory (product_id, quantity) VALUES ($product_id, $quantity)");
  }
  header("Location: inventory.php");
  exit();
}
?>
<html>
<head>
<link rel="stylesheet" href="../assets/style.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <title>Inventory Management</title>
</head>
<body>
  <?php include 'navbar.php'; ?>
  <div class="container mt-4">
    <h1>Inventory Management</h1>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Product ID</th><th>Product Name</th><th>Current Quantity</th><th>Update Quantity</th>
        </tr>
      </thead>
      <tbody>
      <?php while($row = $products->fetch_assoc()){ ?>
        <tr>
          <td><?php echo $row['id']; ?></td>
          <td><?php echo $row['name']; ?></td>
          <td><?php echo isset($row['quantity']) ? $row['quantity'] : 0; ?></td>
          <td>
            <form method="post" class="form-inline">
              <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
              <input type="number" name="quantity" class="form-control mr-2" value="<?php echo isset($row['quantity']) ? $row['quantity'] : 0; ?>" required>
              <button type="submit" name="update_inventory" class="btn btn-primary btn-sm">Update</button>
            </form>
          </td>
        </tr>
      <?php } ?>
      </tbody>
    </table>
  </div>
</body>
</html>
