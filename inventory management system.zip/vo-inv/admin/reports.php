<?php
session_start();
include '../db.php'; // your DB connection
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Reports | Digital Stock</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--mid-gray);
        }

        .page-title {
            font-weight: 600;
            color: var(--primary);
            font-size: 1.5rem;
            margin: 0;
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            border: none;
            margin-bottom: 1.5rem;
        }

        .card-header {
            background: linear-gradient(to right, var(--primary-light), var(--secondary));
            color: white;
            border-radius: 12px 12px 0 0 !important;
            padding: 1rem 1.25rem;
            font-weight: 600;
        }

        .card-body {
            padding: 1.5rem;
        }

        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid var(--mid-gray);
            padding: 0.6rem 1rem;
            font-size: 0.95rem;
            box-shadow: var(--shadow-sm);
            transition: all var(--transition-fast);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(87, 197, 182, 0.25);
        }

        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.25rem;
            font-weight: 500;
            transition: all var(--transition-fast);
        }

        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: var(--primary);
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: none;
            padding: 0.75rem 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-color: var(--mid-gray);
            font-size: 0.95rem;
        }

        .table tbody tr:hover {
            background-color: rgba(87, 197, 182, 0.05);
        }

        .alert {
            border-radius: 8px;
            box-shadow: var(--shadow-sm);
            border: none;
        }

        .report-options {
            background-color: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .report-results {
            background-color: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            overflow: hidden;
        }

        .report-header {
            background: linear-gradient(to right, var(--primary-light), var(--secondary));
            color: white;
            padding: 1rem 1.5rem;
            font-weight: 600;
            display: flex;
            align-items: center;
        }

        .report-header i {
            margin-right: 0.75rem;
            font-size: 1.25rem;
        }

        .report-body {
            padding: 1.5rem;
        }

        .form-label {
            font-weight: 500;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .print-btn {
            background-color: var(--success);
            border-color: var(--success);
            color: white;
        }

        .print-btn:hover {
            background-color: #0da56f;
            border-color: #0da56f;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        @media print {
            .sidebar, .navbar, .report-options, .no-print {
                display: none !important;
            }
            
            .content-wrapper {
                margin-left: 0 !important;
                margin-top: 0 !important;
                padding: 0 !important;
            }
            
            .report-results {
                box-shadow: none;
                border-radius: 0;
            }
            
            .report-header {
                background: none;
                color: var(--text-dark);
                border-bottom: 2px solid var(--primary);
                padding: 0.5rem 0;
            }
            
            body {
                background-color: white;
            }
        }
    </style>
</head>
<body>
<?php include_once("nav.php"); ?>

<div class="content-wrapper">
    <div class="page-header">
        <h1 class="page-title">Generate Reports</h1>
    </div>

    <div class="report-options">
        <div class="mb-4">
            <label for="reportType" class="form-label">
                <i class="fas fa-file-alt me-2"></i> Select Report Type
            </label>
            <select id="reportType" class="form-select">
                <option value="">-- Select Report Type --</option>
                <option value="sales">Sales Orders Report</option>
                <option value="purchase">Purchase Orders Report</option>
            </select>
        </div>

        <div id="dateForm" class="row g-3 mb-3" style="display:none;">
            <div class="col-md-5">
                <label for="startDate" class="form-label">
                    <i class="fas fa-calendar-alt me-2"></i> Start Date
                </label>
                <input type="date" id="startDate" class="form-control">
            </div>
            <div class="col-md-5">
                <label for="endDate" class="form-label">
                    <i class="fas fa-calendar-alt me-2"></i> End Date
                </label>
                <input type="date" id="endDate" class="form-control">
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button id="generateBtn" class="btn btn-primary w-100">
                    <i class="fas fa-chart-bar me-2"></i> Generate
                </button>
            </div>
        </div>
    </div>

    <div id="orderList" class="mt-4"></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(function(){
    // Set default dates (current month)
    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    
    const formatDate = (date) => {
        const d = new Date(date);
        let month = '' + (d.getMonth() + 1);
        let day = '' + d.getDate();
        const year = d.getFullYear();
        
        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;
        
        return [year, month, day].join('-');
    };
    
    $('#startDate').val(formatDate(firstDay));
    $('#endDate').val(formatDate(today));

    // Show/hide date form when report type is selected
    $('#reportType').on('change', function(){
        if (this.value) {
            $('#dateForm').show();
            $('#orderList').empty();
        } else {
            $('#dateForm').hide();
            $('#orderList').empty();
        }
    });

    // Generate report when button is clicked
    $('#generateBtn').on('click', function(){
        let type = $('#reportType').val(),
            start = $('#startDate').val(),
            end = $('#endDate').val();
            
        if (!type || !start || !end) {
            return alert('Please select report type, start date, and end date.');
        }

        // Show loading indicator
        $('#orderList').html('<div class="d-flex justify-content-center my-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>');

        // Pick correct endpoint based on report type
        let url = type === 'purchase' ? 'fetch_purchase_order.php' : 'fetch_sales_order.php';

        // Fetch report data
        $.post(url, { start_date: start, end_date: end })
            .done(function(html){
                $('#orderList').html(`
                    <div class="report-results">
                        <div class="report-header">
                            <i class="fas fa-${type === 'purchase' ? 'shopping-cart' : 'file-invoice'}"></i>
                            ${type === 'purchase' ? 'Purchase' : 'Sales'} Orders Report (${start} to ${end})
                        </div>
                        <div class="report-body">
                            <div class="d-flex justify-content-end mb-3 no-print">
                                <button class="btn print-btn" onclick="window.print()">
                                    <i class="fas fa-print me-2"></i> Print Report
                                </button>
                            </div>
                            ${html}
                        </div>
                    </div>
                `);
            })
            .fail(function(xhr){
                $('#orderList').html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Error: ${xhr.statusText}
                    </div>
                `);
            });
    });
});
</script>
</body>
</html>