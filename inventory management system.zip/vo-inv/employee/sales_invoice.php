<?php
include '../db.php'; // Ensure correct path

// Get Order ID from URL
$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

// Fetch Order Details (including VAT and Discount)
$order_sql = "SELECT id, customer_name, order_date, vat, discount, total_amount FROM orders WHERE id = ?";
$order_stmt = $conn->prepare($order_sql);
$order_stmt->bind_param("i", $order_id);
$order_stmt->execute();
$order_result = $order_stmt->get_result();
$order = $order_result->fetch_assoc();

if (!$order) {
    die("Order not found or invalid order ID!");
}

// Fetch Ordered Products
$items_sql = "SELECT oi.quantity, oi.line_total, 
                     p.name AS product_name, p.price 
              FROM order_items oi
              JOIN products p ON oi.product_id = p.id
              WHERE oi.order_id = ?";

$items_stmt = $conn->prepare($items_sql);
$items_stmt->bind_param("i", $order_id);
$items_stmt->execute();
$items_result = $items_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?= htmlspecialchars($order['id']); ?> | Digital Stock</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .invoice-container {
            max-width: 800px;
            margin: 2rem auto;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
        }

        .invoice-header {
            background: linear-gradient(to right, var(--primary), var(--secondary));
            color: white;
            padding: 2rem;
            position: relative;
        }

        .invoice-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .invoice-subtitle {
            opacity: 0.8;
            font-size: 1rem;
        }

        .invoice-id {
            position: absolute;
            top: 2rem;
            right: 2rem;
            font-size: 1.5rem;
            font-weight: 700;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1rem;
            border-radius: 8px;
            backdrop-filter: blur(4px);
        }

        .invoice-body {
            padding: 2rem;
        }

        .invoice-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 2rem;
        }

        .invoice-info-item {
            flex: 1;
        }

        .invoice-info-label {
            font-size: 0.875rem;
            color: var(--text-muted);
            margin-bottom: 0.25rem;
        }

        .invoice-info-value {
            font-size: 1rem;
            font-weight: 600;
        }

        .table {
            margin-bottom: 2rem;
        }

        .table thead th {
            background-color: var(--primary);
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: none;
            padding: 0.75rem 1rem;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-color: var(--mid-gray);
        }

        .table tfoot {
            background-color: var(--light-gray);
        }

        .table tfoot td {
            padding: 0.75rem 1rem;
            font-weight: 600;
        }

        .table tfoot .grand-total {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--primary);
        }

        .invoice-footer {
            padding: 1.5rem 2rem;
            background-color: var(--light-gray);
            text-align: center;
            border-top: 1px solid var(--mid-gray);
        }

        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.25rem;
            font-weight: 500;
            transition: all var(--transition-fast);
        }

        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        @media print {
            body {
                background: white;
            }
            
            .invoice-container {
                box-shadow: none;
                margin: 0;
                max-width: 100%;
            }
            
            .invoice-footer {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="invoice-container">
    <div class="invoice-header">
        <div class="invoice-title">Sales Invoice</div>
        <div class="invoice-subtitle">Digital Stock Management System</div>
        <div class="invoice-id">#<?= htmlspecialchars($order['id']); ?></div>
    </div>
    
    <div class="invoice-body">
        <div class="invoice-info">
            <div class="invoice-info-item">
                <div class="invoice-info-label">Customer</div>
                <div class="invoice-info-value"><?= htmlspecialchars($order['customer_name']); ?></div>
            </div>
            <div class="invoice-info-item">
                <div class="invoice-info-label">Invoice Date</div>
                <div class="invoice-info-value"><?= date("F d, Y", strtotime($order['order_date'])); ?></div>
            </div>
            <div class="invoice-info-item text-end">
                <div class="invoice-info-label">Status</div>
                <div class="invoice-info-value">
                    <span class="badge bg-success">Paid</span>
                </div>
            </div>
        </div>
        
        <table class="table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th class="text-end">Unit Price</th>
                    <th class="text-end">Quantity</th>
                    <th class="text-end">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $subtotal = 0;
                while ($item = $items_result->fetch_assoc()): 
                    $subtotal += $item['line_total'];
                ?>
                <tr>
                    <td><?= htmlspecialchars($item['product_name']); ?></td>
                    <td class="text-end">$<?= number_format($item['price'], 2); ?></td>
                    <td class="text-end"><?= htmlspecialchars($item['quantity']); ?></td>
                    <td class="text-end">$<?= number_format($item['line_total'], 2); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="text-end">Subtotal</td>
                    <td class="text-end">$<?= number_format($subtotal, 2); ?></td>
                </tr>
                <tr>
                    <td colspan="3" class="text-end">VAT (13%)</td>
                    <td class="text-end">$<?= number_format($order['vat'], 2); ?></td>
                </tr>
                <tr>
                    <td colspan="3" class="text-end">Discount</td>
                    <td class="text-end">$<?= number_format($order['discount'], 2); ?></td>
                </tr>
                <tr>
                    <td colspan="3" class="text-end">Grand Total</td>
                    <td class="text-end grand-total">$<?= number_format($order['total_amount'], 2); ?></td>
                </tr>
            </tfoot>
        </table>
        
        <div class="text-center mt-4">
            <p class="mb-0">Thank you for your business!</p>
        </div>
    </div>
    
    <div class="invoice-footer">
        <button class="btn btn-primary" onclick="window.print()">
            <i class="fas fa-print me-2"></i> Print Invoice
        </button>
        <a href="reports.php" class="btn btn-outline-secondary ms-2">
            <i class="fas fa-arrow-left me-2"></i> Back to Reports
        </a>
    </div>
</div>

</body>
</html>

<?php
$conn->close();
?>
