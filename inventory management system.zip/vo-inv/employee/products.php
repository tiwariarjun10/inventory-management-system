<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'employee') {
    header("Location: ../login.php");
    exit();
}
require_once '../db.php';

// Get filter parameter
$filter = isset($_GET['filter']) ? $_GET['filter'] : '';

// Base query
$base_query = "SELECT p.*, c.name as category_name, b.name as brand_name 
               FROM products p 
               LEFT JOIN categories c ON p.category_id = c.id 
               LEFT JOIN brands b ON p.brand_id = b.id";

// Apply filter if specified
if ($filter == 'low_stock') {
    $query = $base_query . " WHERE p.quantity <= 10 ORDER BY p.quantity ASC";
    $filter_title = "Low Stock Products";
} else {
    $query = $base_query . " ORDER BY p.name ASC";
    $filter_title = "All Products";
}

// Execute query
$result = $conn->query($query);

// Check for errors
if (!$result) {
    $error = "Query error: " . $conn->error;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products | Digital Stock</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--mid-gray);
        }

        .page-title {
            font-weight: 600;
            color: var(--primary);
            font-size: 1.5rem;
            margin: 0;
        }

        .filter-badge {
            display: inline-flex;
            align-items: center;
            background: linear-gradient(135deg, var(--warning) 0%, var(--danger) 100%);
            color: white;
            padding: 0.4rem 0.8rem;
            border-radius: 50rem;
            font-size: 0.8rem;
            font-weight: 600;
            margin-left: 0.75rem;
            box-shadow: var(--shadow-sm);
        }

        .filter-badge i {
            margin-right: 0.4rem;
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            border: none;
            margin-bottom: 1.5rem;
        }

        .card-header {
            background: linear-gradient(to right, var(--primary-light), var(--secondary));
            color: white;
            border-radius: 12px 12px 0 0 !important;
            padding: 1rem 1.25rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card-header .left {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: 1.5rem;
        }

        .search-container {
            margin-bottom: 1.5rem;
        }

        .input-group {
            box-shadow: var(--shadow-sm);
            border-radius: 8px;
            overflow: hidden;
        }

        .input-group-text {
            background-color: var(--primary);
            color: white;
            border: none;
            padding-left: 1rem;
            padding-right: 1rem;
        }

        .form-control {
            border: 1px solid var(--mid-gray);
            padding: 0.6rem 1rem;
            font-size: 0.95rem;
            border-left: none;
        }

        .form-control:focus {
            box-shadow: none;
            border-color: var(--mid-gray);
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: var(--primary);
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: none;
            padding: 0.75rem 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-color: var(--mid-gray);
            font-size: 0.95rem;
        }

        .table tbody tr:hover {
            background-color: rgba(87, 197, 182, 0.05);
        }

        .stock-indicator {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.4rem 0.75rem;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.8rem;
        }

        .stock-low {
            background-color: rgba(239, 68, 68, 0.15);
            color: var(--danger);
        }

        .stock-warning {
            background-color: rgba(245, 158, 11, 0.15);
            color: var(--warning);
        }

        .stock-ok {
            background-color: rgba(16, 185, 129, 0.15);
            color: var(--success);
        }

        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.25rem;
            font-weight: 500;
            transition: all var(--transition-fast);
        }

        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-outline-primary {
            color: var(--primary);
            border-color: var(--primary);
        }

        .btn-outline-primary:hover {
            background-color: var(--primary);
            border-color: var(--primary);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .empty-state {
            text-align: center;
            padding: 2rem 1.5rem;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--mid-gray);
        }

        .empty-state h3 {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--text-dark);
        }

        .empty-state p {
            max-width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
<?php include_once("nav.php"); ?>

<div class="container mt-4">
    <div class="page-header">
        <h1 class="page-title">
            <?php echo $filter_title; ?>
            <?php if($filter == 'low_stock'): ?>
                <span class="filter-badge">
                    <i class="fas fa-exclamation-triangle"></i> Low Stock Filter
                </span>
            <?php endif; ?>
        </h1>
        
        <div class="header-actions">
            <?php if($filter == 'low_stock'): ?>
                <a href="products.php" class="btn btn-outline-primary">
                    <i class="fas fa-list me-2"></i> View All Products
                </a>
            <?php else: ?>
                <a href="products.php?filter=low_stock" class="btn btn-outline-primary">
                    <i class="fas fa-exclamation-triangle me-2"></i> View Low Stock
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="search-container">
        <div class="row">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                    <input type="text" id="productSearch" class="form-control" placeholder="Search products by name, category, brand...">
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="left">
                <i class="fas fa-box-open me-2"></i> Product List
            </div>
            <?php if(isset($result) && $result->num_rows > 0): ?>
                <span class="badge bg-primary"><?php echo $result->num_rows; ?> Products</span>
            <?php endif; ?>
        </div>
        <div class="card-body p-0">
            <?php if(isset($error)): ?>
                <div class="alert alert-danger m-3">
                    <?php echo $error; ?>
                </div>
            <?php elseif(isset($result) && $result->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Brand</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['category_name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($row['brand_name'] ?? 'N/A'); ?></td>
                                    <td>$<?php echo number_format($row['price'], 2); ?></td>
                                    <td><?php echo $row['quantity']; ?></td>
                                    <td>
                                        <?php 
                                        $quantity = (int)$row['quantity'];
                                        if($quantity == 0): ?>
                                            <span class="stock-indicator stock-low">
                                                <i class="fas fa-exclamation-circle"></i> Out of Stock
                                            </span>
                                        <?php elseif($quantity <= 5): ?>
                                            <span class="stock-indicator stock-low">
                                                <i class="fas fa-exclamation-circle"></i> Critical
                                            </span>
                                        <?php elseif($quantity <= 10): ?>
                                            <span class="stock-indicator stock-warning">
                                                <i class="fas fa-exclamation-triangle"></i> Low Stock
                                            </span>
                                        <?php else: ?>
                                            <span class="stock-indicator stock-ok">
                                                <i class="fas fa-check-circle"></i> In Stock
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <h3>No Products Found</h3>
                    <p>
                        <?php if($filter == 'low_stock'): ?>
                            There are currently no products with low stock levels.
                        <?php else: ?>
                            There are no products in the database. Please add some products.
                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('productSearch').addEventListener('keyup', function() {
        const searchValue = this.value.toLowerCase();
        const table = document.querySelector('.table');
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            let found = false;
            const cells = row.querySelectorAll('td');
            
            cells.forEach(cell => {
                if (cell.textContent.toLowerCase().includes(searchValue)) {
                    found = true;
                }
            });
            
            row.style.display = found ? '' : 'none';
        });
    });
</script>
</body>
</html>
