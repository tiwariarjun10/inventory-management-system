<?php
session_start();
// must be employee
if(!isset($_SESSION['role'])||$_SESSION['role']!=='employee'){
  header("Location: ../login.php");
  exit;
}
require_once '../db.php';

if(isset($_POST['mark_done'])){
  $oid = (int)$_POST['order_id'];
  // 1) deduct stock now
  $items = $conn->query(
    "SELECT product_id, quantity FROM order_items WHERE order_id=$oid"
  );
  while($it=$items->fetch_assoc()){
    $conn->query(
      "UPDATE products
         SET quantity=quantity - {$it['quantity']}
       WHERE id={$it['product_id']}"
    );
  }
  // 2) update order status
  $conn->query("UPDATE orders SET status='done' WHERE id=$oid");
}

$res = $conn->query("
  SELECT o.id, o.order_date, o.customer_name, o.contact,
         GROUP_CONCAT(p.name,' x ',i.quantity SEPARATOR ' | ') AS products
  FROM orders o
  JOIN order_items i ON o.id=i.order_id
  JOIN products p ON i.product_id=p.id
  WHERE o.status='pending'
  GROUP BY o.id
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Orders | Digital Stock</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .navbar {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            box-shadow: var(--shadow-md);
            padding: 0.75rem 1.5rem;
        }

        .navbar-brand {
            font-weight: 700;
            color: var(--text-light);
            font-size: 1.25rem;
            display: flex;
            align-items: center;
        }

        .navbar-brand i {
            margin-right: 0.75rem;
            font-size: 1.5rem;
            color: var(--accent-light);
        }

        .nav-link {
            color: var(--text-light);
            font-weight: 500;
            transition: all var(--transition-fast);
            padding: 0.5rem 1rem;
            border-radius: 6px;
        }

        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateY(-1px);
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--mid-gray);
        }

        .page-title {
            font-weight: 600;
            color: var(--primary);
            font-size: 1.5rem;
            margin: 0;
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            border: none;
            margin-bottom: 1.5rem;
        }

        .card-header {
            background: linear-gradient(to right, var(--primary-light), var(--secondary));
            color: white;
            border-radius: 12px 12px 0 0 !important;
            padding: 1rem 1.25rem;
            font-weight: 600;
        }

        .card-body {
            padding: 1.5rem;
        }

        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.25rem;
            font-weight: 500;
            transition: all var(--transition-fast);
        }

        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-secondary {
            background-color: var(--text-muted);
            border-color: var(--text-muted);
        }

        .btn-secondary:hover {
            background-color: var(--text-dark);
            border-color: var(--text-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-success {
            background-color: var(--success);
            border-color: var(--success);
        }

        .btn-success:hover {
            background-color: #0da56f;
            border-color: #0da56f;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .btn-sm {
            padding: 0.4rem 0.75rem;
            font-size: 0.85rem;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: var(--primary);
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: none;
            padding: 0.75rem 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-color: var(--mid-gray);
            font-size: 0.95rem;
        }

        .table tbody tr:hover {
            background-color: rgba(87, 197, 182, 0.05);
        }

        .alert {
            border-radius: 8px;
            box-shadow: var(--shadow-sm);
            border: none;
        }

        .alert-info {
            background-color: rgba(59, 130, 246, 0.15);
            color: #3b82f6;
        }

        .truncate {
            max-width: 250px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .footer {
            margin-top: 3rem;
            padding: 1.5rem 0;
            text-align: center;
            color: var(--text-muted);
            font-size: 0.9rem;
            border-top: 1px solid var(--mid-gray);
        }

        .content-wrapper {
            padding: 1.5rem;
            margin-top: 4rem;
        }
    </style>
</head>
<body>
<?php include_once("nav.php"); ?>

<div class="container content-wrapper">
    <div class="page-header">
        <h1 class="page-title">Pending Orders</h1>
        <a href="dashboard.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
        </a>
    </div>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-clipboard-check me-2"></i> Orders Awaiting Processing
        </div>
        <div class="card-body p-0">
            <?php if($res && $res->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Date</th>
                                <th>Customer</th>
                                <th>Contact</th>
                                <th>Products</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($r = $res->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?= $r['id'] ?></td>
                                    <td><?= date('M d, Y', strtotime($r['order_date'])) ?></td>
                                    <td><?= htmlspecialchars($r['customer_name']) ?></td>
                                    <td><?= htmlspecialchars($r['contact']) ?></td>
                                    <td class="truncate" title="<?= htmlspecialchars($r['products']) ?>"><?= htmlspecialchars($r['products']) ?></td>
                                    <td>
                                        <form method="POST" style="display:inline">
                                            <input type="hidden" name="order_id" value="<?= $r['id'] ?>">
                                            <button name="mark_done" class="btn btn-success btn-sm" onclick="return confirm('Are you sure you want to mark this order as done? This will update inventory.');">
                                                <i class="fas fa-check me-1"></i> Mark Done
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info m-3">
                    <i class="fas fa-info-circle me-2"></i> No pending orders at this time.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> Digital Stock Management System. All rights reserved.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
