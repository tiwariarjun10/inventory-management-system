<?php
// Example: we store user role in $_SESSION['role'] = 'admin' or 'employee' or others
$roleText = 'GUEST';
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'admin') {
        $roleText = 'ADMIN';
    } elseif ($_SESSION['role'] === 'employee') {
        $roleText = 'EMPLOYEE';
    } else {
        $roleText = strtoupper($_SESSION['role']);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Digital Stock Management</title>

  <!-- Bootstrap 5 CSS -->
  <link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
  />
  <!-- Font Awesome for Icons -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  />
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <style>
  :root {
    /* Main color palette */
    --primary: #1a5f7a;
    --primary-dark: #124b61;
    --primary-light: #2e7d9a;
    --secondary: #159895;
    --accent: #57c5b6;
    --accent-light: #7dd3c8;
    --dark: #1e293b;
    --light: #f8fafc;
    --light-gray: #f1f5f9;
    --mid-gray: #e2e8f0;
    --text-dark: #334155;
    --text-muted: #64748b;
    --text-light: #f8fafc;
    --danger: #ef4444;
    --warning: #f59e0b;
    --success: #10b981;
    
    /* Shadows */
    --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    
    /* Transitions */
    --transition-fast: 0.15s ease;
    --transition-normal: 0.3s ease;
    --transition-slow: 0.5s ease;
  }

  body {
    background-color: var(--light-gray);
    color: var(--text-dark);
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
    overflow-x: hidden;
  }

  /* NAVBAR */
  .navbar {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 999;
    height: 64px;
    box-shadow: var(--shadow-md);
    padding: 0 1.5rem;
  }

  .navbar-brand {
    font-weight: 700;
    color: var(--text-light);
    font-size: 1.25rem;
    display: flex;
    align-items: center;
    letter-spacing: 0.5px;
  }

  .navbar-brand i {
    margin-right: 0.75rem;
    font-size: 1.5rem;
    color: var(--accent-light);
    filter: drop-shadow(0 2px 2px rgba(0, 0, 0, 0.2));
  }

  .navbar .nav-item {
    display: flex;
    align-items: center;
  }

  .navbar .nav-link {
    color: var(--text-light);
    font-weight: 500;
    transition: all var(--transition-fast);
    padding: 0.5rem 1rem;
    border-radius: 6px;
  }

  .navbar .nav-link:hover {
    background-color: rgba(255, 255, 255, 0.15);
    transform: translateY(-1px);
  }

  .role-badge {
    background: rgba(255, 255, 255, 0.2);
    color: var(--text-light);
    padding: 0.35rem 0.75rem;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.5px;
    margin-right: 1rem;
    backdrop-filter: blur(4px);
    border: 1px solid rgba(255, 255, 255, 0.1);
  }

  .logout-btn {
    display: flex;
    align-items: center;
    background-color: rgba(255, 255, 255, 0.1);
    border-radius: 6px;
    padding: 0.5rem 1rem;
    transition: all var(--transition-fast);
  }

  .logout-btn:hover {
    background-color: rgba(255, 255, 255, 0.2);
    transform: translateY(-1px);
  }

  .logout-btn i {
    margin-right: 0.5rem;
  }
</style>

</head>
<body>
<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid px-0">
    <a class="navbar-brand" href="dashboard.php">
      <i class="fas fa-cubes"></i>
      <span>DIGITAL STOCK</span>
    </a>
    <ul class="navbar-nav ms-auto">
      <li class="nav-item">
        <span class="role-badge"><?php echo $roleText; ?></span>
      </li>
      <li class="nav-item">
        <a class="nav-link logout-btn" href="../logout.php">
          <i class="fas fa-sign-out-alt"></i>Logout
        </a>
      </li>
    </ul>
  </div>
</nav>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
