<?php
include '../db.php';

if (isset($_POST['start_date'], $_POST['end_date'])) {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Fetch orders within date range
    $query = "SELECT id, customer_name, order_date, total_amount FROM orders 
              WHERE order_date BETWEEN ? AND ? ORDER BY order_date ASC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<h4>Orders from $start_date to $end_date</h4>";
        echo "<table class='table table-bordered'>
                <tr>
                    <th>Invoice #</th>
                    <th>Customer Name</th>
                    <th>Order Date</th>
                    <th>Total Amount</th>
                    <th>Action</th>
                </tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['customer_name']}</td>
                    <td>{$row['order_date']}</td>
                    <td>$" . number_format($row['total_amount'], 2) . "</td>
                    <td><a href='sales_invoice.php?order_id={$row['id']}' target='_blank' class='btn btn-success'>Print Invoice</a></td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='text-danger'>No orders found in this date range.</p>";
    }
}
?>
