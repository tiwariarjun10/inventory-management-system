<?php
include '../db.php';

if (isset($_POST['start_date'], $_POST['end_date'])) {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Fetch purchase orders within date range
    $query = "SELECT po.id, s.name AS supplier_name, po.order_date, po.vat, po.discount, po.total_amount
              FROM purchase_orders po
              JOIN suppliers s ON po.supplier_id = s.id
              WHERE po.order_date BETWEEN ? AND ?
              ORDER BY po.order_date ASC";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("<p class='text-danger'>Query preparation failed: " . htmlspecialchars($conn->error) . "</p>");
    }

    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<h4>Purchase Orders from $start_date to $end_date</h4>";
        echo "<table class='table table-bordered'>
                <tr>
                    <th>PO #</th>
                    <th>Supplier Name</th>
                    <th>Order Date</th>
                    <th>VAT (%)</th>
                    <th>Discount (%)</th>
                    <th>Total Amount</th>
                    <th>Action</th>
                </tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>" . htmlspecialchars($row['supplier_name']) . "</td>
                    <td>{$row['order_date']}</td>
                    <td>{$row['vat']}</td>
                    <td>{$row['discount']}</td>
                    <td>$" . number_format($row['total_amount'], 2) . "</td>
                    <td><a href='purchase_invoice.php?po_id={$row['id']}' target='_blank' class='btn btn-success'>Print Invoice</a></td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='text-danger'>No purchase orders found in this date range.</p>";
    }

    $stmt->close();
}
?>
