<?php
include '../db.php'; // Ensure this is the correct path to your DB connection

// Get Purchase Order ID from URL
$po_id = isset($_GET['po_id']) ? intval($_GET['po_id']) : 0;

// Fetch Purchase Order Details
$order_sql = "SELECT po.id, s.name AS supplier_name, po.order_date, po.vat, po.discount, po.total_amount 
              FROM purchase_orders po
              JOIN suppliers s ON po.supplier_id = s.id
              WHERE po.id = ?";
$order_stmt = $conn->prepare($order_sql);
$order_stmt->bind_param("i", $po_id);
$order_stmt->execute();
$order_result = $order_stmt->get_result();
$order = $order_result->fetch_assoc();

if (!$order) {
    die("Purchase order not found or invalid ID!");
}

// Optional: If you have a purchase_items table, fetch purchased products
$items_result = []; // Placeholder array for items
$has_items = false;

// Uncomment and use this if you have a purchase_items table
/*
$items_sql = "SELECT pi.quantity, pi.line_total, p.name AS product_name, p.price 
              FROM purchase_items pi
              JOIN products p ON pi.product_id = p.id
              WHERE pi.purchase_id = ?";
$items_stmt = $conn->prepare($items_sql);
$items_stmt->bind_param("i", $po_id);
$items_stmt->execute();
$items_result = $items_stmt->get_result();
$has_items = true;
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Invoice #<?= htmlspecialchars($order['id']); ?> | Digital Stock</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .invoice-container {
            max-width: 800px;
            margin: 2rem auto;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
        }

        .invoice-header {
            background: linear-gradient(to right, var(--secondary), var(--accent));
            color: white;
            padding: 2rem;
            position: relative;
        }

        .invoice-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .invoice-subtitle {
            opacity: 0.8;
            font-size: 1rem;
        }

        .invoice-id {
            position: absolute;
            top: 2rem;
            right: 2rem;
            font-size: 1.5rem;
            font-weight: 700;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1rem;
            border-radius: 8px;
            backdrop-filter: blur(4px);
        }

        .invoice-body {
            padding: 2rem;
        }

        .invoice-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 2rem;
        }

        .invoice-info-item {
            flex: 1;
        }

        .invoice-info-label {
            font-size: 0.875rem;
            color: var(--text-muted);
            margin-bottom: 0.25rem;
        }

        .invoice-info-value {
            font-size: 1rem;
            font-weight: 600;
        }

        .table {
            margin-bottom: 2rem;
        }

        .table thead th {
            background-color: var(--secondary);
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: none;
            padding: 0.75rem 1rem;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-color: var(--mid-gray);
        }

        .table tfoot {
            background-color: var(--light-gray);
        }

        .table tfoot td {
            padding: 0.75rem 1rem;
            font-weight: 600;
        }

        .table tfoot .grand-total {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--secondary);
        }

        .invoice-footer {
            padding: 1.5rem 2rem;
            background-color: var(--light-gray);
            text-align: center;
            border-top: 1px solid var(--mid-gray);
        }

        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.25rem;
            font-weight: 500;
            transition: all var(--transition-fast);
        }

        .btn-primary {
            background-color: var(--secondary);
            border-color: var(--secondary);
        }

        .btn-primary:hover {
            background-color: var(--accent);
            border-color: var(--accent);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .summary-table {
            width: 100%;
            max-width: 400px;
            margin-left: auto;
        }

        .summary-table td {
            padding: 0.5rem 1rem;
        }

        .summary-table .total-row td {
            border-top: 2px solid var(--mid-gray);
            font-weight: 700;
            font-size: 1.1rem;
        }

        @media print {
            body {
                background: white;
            }
            
            .invoice-container {
                box-shadow: none;
                margin: 0;
                max-width: 100%;
            }
            
            .invoice-footer {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="invoice-container">
    <div class="invoice-header">
        <div class="invoice-title">Purchase Invoice</div>
        <div class="invoice-subtitle">Digital Stock Management System</div>
        <div class="invoice-id">PO #<?= htmlspecialchars($order['id']); ?></div>
    </div>
    
    <div class="invoice-body">
        <div class="invoice-info">
            <div class="invoice-info-item">
                <div class="invoice-info-label">Supplier</div>
                <div class="invoice-info-value"><?= htmlspecialchars($order['supplier_name']); ?></div>
            </div>
            <div class="invoice-info-item">
                <div class="invoice-info-label">Purchase Date</div>
                <div class="invoice-info-value"><?= date("F d, Y", strtotime($order['order_date'])); ?></div>
            </div>
            <div class="invoice-info-item text-end">
                <div class="invoice-info-label">Status</div>
                <div class="invoice-info-value">
                    <span class="badge bg-success">Completed</span>
                </div>
            </div>
        </div>
        
        <?php if ($has_items && $items_result && $items_result->num_rows > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th class="text-end">Unit Price</th>
                    <th class="text-end">Quantity</th>
                    <th class="text-end">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($item = $items_result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($item['product_name']); ?></td>
                    <td class="text-end">$<?= number_format($item['price'], 2); ?></td>
                    <td class="text-end"><?= htmlspecialchars($item['quantity']); ?></td>
                    <td class="text-end">$<?= number_format($item['line_total'], 2); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i> No item breakdown available for this purchase order.
            </div>
        <?php endif; ?>

        <div class="mt-4">
            <table class="summary-table">
                <tr>
                    <td class="text-end">VAT (13%):</td>
                    <td class="text-end">$<?= number_format($order['vat'], 2); ?></td>
                </tr>
                <tr>
                    <td class="text-end">Discount:</td>
                    <td class="text-end">$<?= number_format($order['discount'], 2); ?></td>
                </tr>
                <tr class="total-row">
                    <td class="text-end">Grand Total:</td>
                    <td class="text-end">$<?= number_format($order['total_amount'], 2); ?></td>
                </tr>
            </table>
        </div>
        
        <div class="text-center mt-5">
            <p class="mb-0">This is a system-generated purchase invoice.</p>
        </div>
    </div>
    
    <div class="invoice-footer">
        <button class="btn btn-primary" onclick="window.print()">
            <i class="fas fa-print me-2"></i> Print Invoice
        </button>
        <a href="reports.php" class="btn btn-outline-secondary ms-2">
            <i class="fas fa-arrow-left me-2"></i> Back to Reports
        </a>
    </div>
</div>

</body>
</html>

<?php $conn->close(); ?>
