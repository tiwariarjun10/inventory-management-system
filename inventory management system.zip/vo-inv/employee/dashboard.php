<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'employee') {
  header("Location: ../login.php");
  exit();
}
require_once '../db.php';

// Debug flag - set to true to see errors
$debug = true;

// Get low stock products - simplified query without reorder_level
$low_stock_query = "SELECT p.*, c.name as category_name, b.name as brand_name 
                    FROM products p 
                    LEFT JOIN categories c ON p.category_id = c.id 
                    LEFT JOIN brands b ON p.brand_id = b.id 
                    WHERE p.quantity <= 10
                    ORDER BY p.quantity ASC
                    LIMIT 10";
$low_stock_result = $conn->query($low_stock_query);

if(!$low_stock_result && $debug) {
  echo "Low stock query error: " . $conn->error;
}

$low_stock_count = 0;
$low_stock_items = [];

if ($low_stock_result) {
    $low_stock_count = $low_stock_result->num_rows;
    while($row = $low_stock_result->fetch_assoc()) {
        $low_stock_items[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Dashboard | Digital Stock</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            /* Main color palette - matching navbar-sidebar */
            --primary: #1a5f7a;
            --primary-dark: #124b61;
            --primary-light: #2e7d9a;
            --secondary: #159895;
            --accent: #57c5b6;
            --accent-light: #7dd3c8;
            --dark: #1e293b;
            --light: #f8fafc;
            --light-gray: #f1f5f9;
            --mid-gray: #e2e8f0;
            --text-dark: #334155;
            --text-muted: #64748b;
            --text-light: #f8fafc;
            --danger: #ef4444;
            --warning: #f59e0b;
            --success: #10b981;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            
            /* Transitions */
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
        }

        body {
            background-color: var(--light-gray);
            font-family: 'Poppins', sans-serif;
            color: var(--text-dark);
        }

        .navbar {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            box-shadow: var(--shadow-md);
            padding: 0.75rem 1.5rem;
        }

        .navbar-brand {
            font-weight: 700;
            color: var(--text-light);
            font-size: 1.25rem;
            display: flex;
            align-items: center;
        }

        .navbar-brand i {
            margin-right: 0.75rem;
            font-size: 1.5rem;
            color: var(--accent-light);
        }

        .nav-link {
            color: var(--text-light);
            font-weight: 500;
            transition: all var(--transition-fast);
            padding: 0.5rem 1rem;
            border-radius: 6px;
        }

        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateY(-1px);
        }

        .welcome-header {
            background: linear-gradient(to right, var(--primary-light), var(--secondary));
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-md);
        }

        .welcome-title {
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .welcome-subtitle {
            font-size: 1.1rem;
            opacity: 0.9;
        }

        .dashboard-card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            padding: 1.5rem;
            height: 100%;
            transition: all var(--transition-normal);
            border-top: 4px solid transparent;
            text-decoration: none;
            color: var(--text-dark);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
            color: var(--text-dark);
        }

        .dashboard-card .icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--primary);
        }

        .dashboard-card .title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .dashboard-card .description {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .card-products {
            border-top-color: var(--primary);
        }

        .card-products .icon {
            color: var(--primary);
        }

        .card-sales {
            border-top-color: var(--success);
        }

        .card-sales .icon {
            color: var(--success);
        }

        .card-orders {
            border-top-color: var(--warning);
        }

        .card-orders .icon {
            color: var(--warning);
        }

        .card-purchases {
            border-top-color: var(--accent);
        }

        .card-purchases .icon {
            color: var(--accent);
        }

        .footer {
            margin-top: 3rem;
            padding: 1.5rem 0;
            text-align: center;
            color: var(--text-muted);
            font-size: 0.9rem;
            border-top: 1px solid var(--mid-gray);
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            border: none;
            margin-bottom: 1.5rem;
            overflow: hidden;
        }

        .card-header {
            background: linear-gradient(to right, var(--primary-light), var(--secondary));
            color: white;
            border-radius: 12px 12px 0 0 !important;
            padding: 1rem 1.25rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: 1.5rem;
        }

        .alert-count {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            background-color: var(--danger);
            color: white;
            border-radius: 50%;
            font-size: 0.75rem;
            font-weight: 700;
            margin-left: 0.5rem;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            background-color: var(--primary);
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: none;
            padding: 0.75rem 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            vertical-align: middle;
            border-color: var(--mid-gray);
            font-size: 0.95rem;
        }

        .table tbody tr:hover {
            background-color: rgba(87, 197, 182, 0.05);
        }

        .stock-indicator {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.4rem 0.75rem;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.8rem;
        }

        .stock-low {
            background-color: rgba(239, 68, 68, 0.15);
            color: var(--danger);
        }

        .stock-warning {
            background-color: rgba(245, 158, 11, 0.15);
            color: var(--warning);
        }

        .empty-state {
            text-align: center;
            padding: 2rem 1.5rem;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--mid-gray);
        }

        .empty-state h3 {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--text-dark);
        }

        .empty-state p {
            max-width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
<?php include_once("nav.php"); ?>

<div class="container mt-4">
    <div class="welcome-header">
        <div class="welcome-title">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</div>
        <div class="welcome-subtitle">Access your employee dashboard to manage inventory and sales.</div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <a href="products.php" class="dashboard-card card-products">
                <div class="icon">
                    <i class="fas fa-box-open"></i>
                </div>
                <div class="title">View Products</div>
                <div class="description">Browse and search the product inventory</div>
            </a>
        </div>
        
        <div class="col-md-3">
            <a href="reports.php" class="dashboard-card card-sales">
                <div class="icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="title">Report</div>
                <div class="description">Generate saled and purchase reports</div>
            </a>
        </div>
        
        <div class="col-md-3">
            <a href="employee_salesorder.php" class="dashboard-card card-orders">
                <div class="icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="title">Sales Orders</div>
                <div class="description">View and process pending sales orders</div>
            </a>
        </div>
        
        
    </div>

    <!-- Low Stock Alerts Section -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-exclamation-triangle me-2"></i> Low Stock Alerts
            <?php if($low_stock_count > 0): ?>
                <span class="alert-count"><?php echo $low_stock_count; ?></span>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <?php if($low_stock_count > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Category</th>
                                <th>Brand</th>
                                <th>Current Stock</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($low_stock_items as $row): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['brand_name']); ?></td>
                                    <td><?php echo $row['quantity']; ?></td>
                                    <td>
                                        <?php if($row['quantity'] == 0): ?>
                                            <span class="stock-indicator stock-low">
                                                <i class="fas fa-exclamation-circle"></i> Out of Stock
                                            </span>
                                        <?php elseif($row['quantity'] <= 5): ?>
                                            <span class="stock-indicator stock-low">
                                                <i class="fas fa-exclamation-circle"></i> Critical
                                            </span>
                                        <?php else: ?>
                                            <span class="stock-indicator stock-warning">
                                                <i class="fas fa-exclamation-triangle"></i> Low Stock
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-end mt-3">
                    <a href="products.php?filter=low_stock" class="btn btn-primary">
                        <i class="fas fa-eye me-2"></i> View All Low Stock Products
                    </a>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-check-circle"></i>
                    <h3>All Products In Stock</h3>
                    <p>There are currently no products with low stock levels. All inventory is at healthy levels.</p>
                    
                    <?php if($debug): ?>
                    <div class="alert alert-info mt-4">
                        <h5>Debug Information</h5>
                        <p>Query: <?php echo $low_stock_query; ?></p>
                        <p>Result: <?php echo $low_stock_result ? 'Success' : 'Failed'; ?></p>
                        <p>Count: <?php echo $low_stock_count; ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> Digital Stock Management System. All rights reserved.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
