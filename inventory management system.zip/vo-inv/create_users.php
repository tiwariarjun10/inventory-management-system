<?php
require_once 'db.php';

// Generate hashed passwords using password_hash()
$admin_password    = password_hash('admin123', PASSWORD_DEFAULT);
$employee_password = password_hash('employee123', PASSWORD_DEFAULT);

// Insert Admin user
$admin_sql = "INSERT INTO users (username, email, password, role, name) 
              VALUES ('admin', 'admin@example.com', '$admin_password', 'admin', 'Admin User')";

// Insert Employee user
$employee_sql = "INSERT INTO users (username, email, password, role, name) 
                 VALUES ('employee', 'employee@example.com', '$employee_password', 'employee', 'Employee User')";

if ($conn->query($admin_sql) === TRUE && $conn->query($employee_sql) === TRUE) {
    echo "Admin and Employee users have been created successfully.";
} else {
    echo "Error: " . $conn->error;
}
?>
